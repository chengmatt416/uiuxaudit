"use strict";
(() => {
  // packages/core/src/verify.ts
  var POS_TOLERANCE_PX = 2;
  var COLOR_TOLERANCE = 3 / 255;
  var ALPHA_TOLERANCE = 0.02;
  var FONT_SIZE_TOLERANCE = 0.51;
  async function figmaGet(path, token) {
    const base = process.env.UA_FIGMA_API ?? "https://api.figma.com/v1";
    const res = await fetch(`${base}/${path}`, {
      headers: { "X-Figma-Token": token },
      signal: AbortSignal.timeout(6e4)
    });
    if (!res.ok) {
      throw new Error(
        `Figma API ${res.status} for /${path}: ${(await res.text()).slice(0, 300)}`
      );
    }
    return await res.json();
  }
  function walk(node, out) {
    out.set(node.name, node);
    for (const c of node.children ?? []) walk(c, out);
  }
  function firstSolidPaint(node) {
    for (const p of node.fills ?? []) {
      if (p.type === "SOLID" && p.visible !== false && p.color && (p.opacity ?? 1) > 0) {
        return p;
      }
    }
    return void 0;
  }
  function colorMatches(paint, expected) {
    if (!paint?.color) return false;
    const o = paint.opacity ?? 1;
    return Math.abs(paint.color.r - expected.r) <= COLOR_TOLERANCE && Math.abs(paint.color.g - expected.g) <= COLOR_TOLERANCE && Math.abs(paint.color.b - expected.b) <= COLOR_TOLERANCE && (expected.a >= 1 ? o >= 1 - ALPHA_TOLERANCE : Math.abs(o - expected.a) <= ALPHA_TOLERANCE);
  }
  function norm(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  async function verifyCapture(opts) {
    const { token, fileKey, capture } = opts;
    const rootName = `page:${capture.slug}`;
    const file = await figmaGet(
      `files/${fileKey}?depth=3`,
      token
    );
    let rootId;
    for (const page of file.document.children ?? []) {
      for (const child of page.children ?? []) {
        if (child.name === rootName) {
          rootId = child.id;
          break;
        }
      }
      if (rootId) break;
    }
    if (!rootId) {
      throw new Error(
        `Frame "${rootName}" not found in file ${fileKey}. Import the capture first.`
      );
    }
    const detail = await figmaGet(
      `files/${fileKey}/nodes?ids=${rootId}&geometry=absolute_bounding_box`,
      token
    );
    const subtree = detail.nodes[rootId]?.document;
    if (!subtree) throw new Error(`Figma returned no subtree for node ${rootId}`);
    const byName = /* @__PURE__ */ new Map();
    walk(subtree, byName);
    const mismatches = [];
    let found = 0;
    for (const cap of capture.nodes) {
      const node = byName.get(cap.id);
      if (!node) {
        mismatches.push({
          id: cap.id,
          field: "missing",
          expected: `${cap.kind} @(${cap.x},${cap.y})`,
          actual: "absent"
        });
        continue;
      }
      found++;
      const bb = node.absoluteBoundingBox;
      if (!bb) {
        mismatches.push({ id: cap.id, field: "missing", expected: "bbox", actual: "none" });
        continue;
      }
      const checks = [
        ["x", bb.x, cap.x],
        ["y", bb.y, cap.y],
        ["w", bb.width, cap.w],
        ["h", bb.height, cap.h]
      ];
      for (const [field, actual, expected] of checks) {
        const delta = Math.abs(actual - expected);
        if (delta > POS_TOLERANCE_PX) {
          mismatches.push({
            id: cap.id,
            field,
            expected: String(Number(expected.toFixed(2))),
            actual: String(Number(actual.toFixed(2))),
            delta: Number(delta.toFixed(2))
          });
        }
      }
      if (cap.bgColor && cap.bgColor.a > 0) {
        const p = firstSolidPaint(node);
        if (!colorMatches(p, cap.bgColor)) {
          mismatches.push({
            id: cap.id,
            field: "bgColor",
            expected: JSON.stringify(cap.bgColor),
            actual: p ? JSON.stringify(p.color) + "@" + (p.opacity ?? 1) : "none"
          });
        }
      }
      if (cap.kind === "text") {
        if (cap.textColor && cap.textColor.a > 0) {
          const p = firstSolidPaint(node);
          if (!colorMatches(p, cap.textColor)) {
            mismatches.push({
              id: cap.id,
              field: "textColor",
              expected: JSON.stringify(cap.textColor),
              actual: p ? JSON.stringify(p.color) + "@" + (p.opacity ?? 1) : "none"
            });
          }
        }
        if (cap.fontSize && node.fontSize) {
          if (Math.abs(node.fontSize - cap.fontSize) > FONT_SIZE_TOLERANCE) {
            mismatches.push({
              id: cap.id,
              field: "fontSize",
              expected: String(cap.fontSize),
              actual: String(node.fontSize)
            });
          }
        }
        if (cap.text && node.characters !== void 0) {
          if (norm(node.characters) !== norm(cap.text)) {
            mismatches.push({
              id: cap.id,
              field: "characters",
              expected: cap.text.slice(0, 60),
              actual: node.characters.slice(0, 60)
            });
          }
        }
      }
    }
    const coverage = capture.nodes.length ? found / capture.nodes.length : 1;
    return {
      slug: capture.slug,
      fileKey,
      total: capture.nodes.length,
      found,
      coverage,
      passed: coverage >= 0.95 && mismatches.length === 0,
      mismatches,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // packages/core/src/apply.ts
  function applyFixesToDoc(doc2, fixes) {
    const nodes = doc2.nodes.map((n) => ({ ...n }));
    const byId = /* @__PURE__ */ new Map();
    for (const n of nodes) byId.set(n.id, n);
    for (const f of fixes) {
      if (!f.nodeId) continue;
      const n = byId.get(f.nodeId);
      if (!n) continue;
      switch (f.kind) {
        case "setTextColor":
          n.textColor = { ...f.value };
          break;
        case "setBackgroundColor":
          n.bgColor = { ...f.value };
          break;
        case "setFontSize":
          n.fontSize = f.value;
          break;
        case "setSize":
          n.w = f.w;
          n.h = f.h;
          break;
        case "setSnapY":
          n.y = f.value;
          break;
      }
    }
    return { ...doc2, nodes, capturedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  function fixesToFigmaOps(fixes) {
    const ops = [];
    for (const f of fixes) {
      switch (f.kind) {
        case "setTextColor":
          ops.push({ id: f.nodeId, op: "setFill", value: f.value });
          break;
        case "setBackgroundColor":
          ops.push({ id: f.nodeId, op: "setBackground", value: f.value });
          break;
        case "setFontSize":
          ops.push({ id: f.nodeId, op: "setFontSize", value: f.value });
          break;
        case "setSize":
          ops.push({ id: f.nodeId, op: "setSize", w: f.w, h: f.h });
          break;
        case "setSnapY":
          ops.push({ id: f.nodeId, op: "setSnapY", value: f.value });
          break;
      }
    }
    return ops;
  }

  // packages/core/src/suggest.ts
  function srgbLinear(u) {
    return u <= 0.03928 ? u / 12.92 : Math.pow((u + 0.055) / 1.055, 2.4);
  }
  function luminance(c) {
    return 0.2126 * srgbLinear(c.r) + 0.7152 * srgbLinear(c.g) + 0.0722 * srgbLinear(c.b);
  }
  function contrastRatio(a, b) {
    const l1 = luminance(a);
    const l2 = luminance(b);
    const hi = Math.max(l1, l2);
    const lo = Math.min(l1, l2);
    return (hi + 0.05) / (lo + 0.05);
  }
  var BLACK = { r: 0, g: 0, b: 0, a: 1 };
  var WHITE = { r: 1, g: 1, b: 1, a: 1 };
  function blendToward(c, target, f) {
    return {
      r: round4(c.r + (target.r - c.r) * f),
      g: round4(c.g + (target.g - c.g) * f),
      b: round4(c.b + (target.b - c.b) * f),
      a: c.a
    };
  }
  function round4(n) {
    return Math.round(n * 1e4) / 1e4;
  }
  function adjustForContrast(fg, bg, targetRatio) {
    let bestF = Infinity;
    let bestC = null;
    for (const t of [BLACK, WHITE]) {
      if (contrastRatio(blendToward(fg, t, 1), bg) < targetRatio) continue;
      let lo = 0;
      let hi = 1;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (contrastRatio(blendToward(fg, t, mid), bg) >= targetRatio) hi = mid;
        else lo = mid;
      }
      if (hi < bestF) {
        bestF = hi;
        bestC = blendToward(fg, t, hi);
      }
    }
    if (!bestC) return null;
    const quantize = (c) => ({
      r: Math.round(c.r * 255) / 255,
      g: Math.round(c.g * 255) / 255,
      b: Math.round(c.b * 255) / 255,
      a: c.a
    });
    const darker = bestC.r + bestC.g + bestC.b <= fg.r + fg.g + fg.b;
    const extreme = darker ? BLACK : WHITE;
    for (let k = 0; k < 16; k++) {
      const cand = quantize(
        blendToward(fg, extreme, Math.min(1, bestF + k / 255))
      );
      if (contrastRatio(cand, bg) >= targetRatio) return cand;
    }
    return quantize(bestC);
  }
  var SEVERITY_RANK = { error: 0, warn: 1, info: 2 };
  function suggestFor(doc2, limit = 300) {
    const raw = [];
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.textColor || !n.fontSize) continue;
      const bg = n.effectiveBg ?? doc2.rootBg ?? WHITE;
      const large = n.fontSize >= 24 || n.fontSize >= 18.66 && (n.fontWeight ?? 400) >= 700;
      const target = large ? 3 : 4.5;
      const ratio = contrastRatio(n.textColor, bg);
      if (ratio >= target - 1e-9) continue;
      const fixed = adjustForContrast(n.textColor, bg, target);
      raw.push({
        rule: "contrast",
        category: "accessibility",
        severity: ratio < target / 2 ? "error" : "warn",
        message: `Contrast ${ratio.toFixed(2)}:1 < ${target}:1 for ${n.fontSize.toFixed(1)}px "${(n.text ?? "").trim().slice(0, 40)}"`,
        targetIds: [n.id],
        fixes: fixed ? [{ kind: "setTextColor", nodeId: n.id, value: fixed }] : []
      });
    }
    for (const n of doc2.nodes) {
      if (!n.interactive || n.kind === "text") continue;
      if (n.w >= 24 && n.h >= 24) continue;
      raw.push({
        rule: "touch-target",
        category: "interaction",
        severity: "warn",
        message: `<${n.tag.toLowerCase()}> ${n.w.toFixed(0)}x${n.h.toFixed(0)}px below 24x24px minimum`,
        targetIds: [n.id],
        fixes: [
          {
            kind: "setSize",
            nodeId: n.id,
            w: Math.max(n.w, 24),
            h: Math.max(n.h, 24)
          }
        ]
      });
    }
    const freqKey = (fs) => Math.round(fs * 2) / 2;
    const freq = /* @__PURE__ */ new Map();
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.fontSize) continue;
      const k = freqKey(n.fontSize);
      freq.set(k, (freq.get(k) ?? 0) + 1);
    }
    const distinct = [...freq.keys()].sort((a, b) => a - b);
    if (distinct.length > 6) {
      const kept = [...freq.entries()].sort((a, b) => b[1] - a[1] || a[0] - b[0]).slice(0, 4).map((e) => e[0]).sort((a, b) => a - b);
      const fixes = [];
      const targetIds = [];
      for (const n of doc2.nodes) {
        if (n.kind !== "text" || !n.fontSize) continue;
        const k = freqKey(n.fontSize);
        if (kept.includes(k)) continue;
        const nearest = kept.reduce(
          (best, cur) => Math.abs(cur - k) < Math.abs(best - k) ? cur : best
        );
        if (nearest === k) continue;
        targetIds.push(n.id);
        fixes.push({ kind: "setFontSize", nodeId: n.id, value: nearest });
      }
      if (fixes.length) {
        raw.push({
          rule: "font-scale",
          category: "typography",
          severity: "info",
          message: `${distinct.length} distinct font sizes; consolidate outliers onto scale ${kept.join("/")}px (${fixes.length} nodes)`,
          targetIds,
          fixes
        });
      }
    }
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.fontSize || (n.fontSize ?? 16) < 12) continue;
      const estCharsPerLine = n.w / (n.fontSize * 0.5);
      if (estCharsPerLine <= 100) continue;
      raw.push({
        rule: "line-length",
        category: "typography",
        severity: "info",
        message: `Text block spans ~${estCharsPerLine.toFixed(0)} em-halved characters per line (>100); consider constraining measure`,
        targetIds: [n.id],
        fixes: []
      });
    }
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.fontSize) continue;
      if (n.fontSize < 12 && (n.text ?? "").trim().length > 0) {
        raw.push({
          rule: "min-font-size",
          category: "accessibility",
          severity: "warn",
          message: `Font size ${n.fontSize.toFixed(1)}px is below 12px legibility threshold for "${(n.text ?? "").trim().slice(0, 30)}"`,
          targetIds: [n.id],
          fixes: [{ kind: "setFontSize", nodeId: n.id, value: 12 }]
        });
      }
    }
    let lastH = 0;
    for (const n of doc2.nodes) {
      const m = n.tag.toUpperCase().match(/^H([1-6])$/);
      if (!m) continue;
      const cur = parseInt(m[1], 10);
      if (lastH > 0 && cur > lastH + 1) {
        raw.push({
          rule: "heading-hierarchy",
          category: "typography",
          severity: "info",
          message: `Heading level jumped from <h${lastH}> to <h${cur}> without intermediate levels`,
          targetIds: [n.id],
          fixes: []
        });
      }
      lastH = cur;
    }
    for (const n of doc2.nodes) {
      if (!n.interactive || n.kind === "text") continue;
      const tag = n.tag.toUpperCase();
      if (tag === "BUTTON" || tag === "A") {
        const hasTextChild = doc2.nodes.some(
          (o) => (o.parent === n.id || o.x >= n.x - 4 && o.y >= n.y - 4 && o.x <= n.x + n.w + 4 && o.y <= n.y + n.h + 4) && (o.kind === "text" || o.text && o.text.trim().length > 0)
        );
        if (!hasTextChild && (!n.text || n.text.trim().length === 0) && n.w > 0 && n.h > 0) {
          raw.push({
            rule: "interactive-labels",
            category: "accessibility",
            severity: "warn",
            message: `<${n.tag.toLowerCase()}> interactive control has no text or accessible label`,
            targetIds: [n.id],
            fixes: []
          });
        }
      }
    }
    for (const n of doc2.nodes) {
      if (n.kind !== "frame" || n.w < 32 || n.h < 32) continue;
      const isIntW = Math.abs(n.w - Math.round(n.w)) < 1e-3;
      const isIntH = Math.abs(n.h - Math.round(n.h)) < 1e-3;
      if (isIntW && isIntH && n.w % 4 !== 0 && n.h % 4 !== 0 && n.w > 48 && n.h > 48) {
        const snapW = Math.round(n.w / 4) * 4;
        const snapH = Math.round(n.h / 4) * 4;
        raw.push({
          rule: "spacing-rhythm",
          category: "layout",
          severity: "info",
          message: `<${n.tag.toLowerCase()}> ${n.w}\xD7${n.h}px deviates from 4px/8px design grid (nearest: ${snapW}\xD7${snapH}px)`,
          targetIds: [n.id],
          fixes: [{ kind: "setSize", nodeId: n.id, w: snapW, h: snapH }]
        });
      }
    }
    raw.sort(
      (a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || (a.targetIds[0] ?? "").localeCompare(
        (b.targetIds[0] ?? "") || "",
        void 0,
        { numeric: true }
      ) || a.rule.localeCompare(b.rule)
    );
    const truncated = raw.length > limit;
    const picked = raw.slice(0, limit).map((s, i) => ({
      ...s,
      id: "s" + String(i + 1).padStart(3, "0")
    }));
    if (truncated) {
      picked.push({
        id: "s" + String(picked.length + 1).padStart(3, "0"),
        rule: "contrast",
        category: "accessibility",
        severity: "info",
        message: `(+${raw.length - limit} further findings truncated deterministically)`,
        targetIds: [],
        fixes: []
      });
    }
    return picked;
  }
  function calculateAuditScore(doc2, suggestions2) {
    let errorCount = 0;
    let warnCount = 0;
    let infoCount = 0;
    const cats = {
      accessibility: { errors: 0, warns: 0, infos: 0, total: 0 },
      interaction: { errors: 0, warns: 0, infos: 0, total: 0 },
      typography: { errors: 0, warns: 0, infos: 0, total: 0 },
      layout: { errors: 0, warns: 0, infos: 0, total: 0 }
    };
    for (const s of suggestions2) {
      const c = s.category ?? (s.rule === "contrast" || s.rule === "min-font-size" || s.rule === "interactive-labels" ? "accessibility" : s.rule === "touch-target" ? "interaction" : s.rule === "font-scale" || s.rule === "line-length" || s.rule === "heading-hierarchy" ? "typography" : "layout");
      const target = cats[c] || cats.accessibility;
      target.total++;
      if (s.severity === "error") {
        errorCount++;
        target.errors++;
      } else if (s.severity === "warn") {
        warnCount++;
        target.warns++;
      } else {
        infoCount++;
        target.infos++;
      }
    }
    const penalty = errorCount * 12 + warnCount * 4 + infoCount * 1;
    const score = Math.max(0, Math.min(100, 100 - penalty));
    let grade = "F";
    if (score >= 95) grade = "A+";
    else if (score >= 90) grade = "A";
    else if (score >= 80) grade = "B";
    else if (score >= 70) grade = "C";
    else if (score >= 60) grade = "D";
    let wcagLevel = "AAA";
    if (errorCount > 0) wcagLevel = "Non-compliant";
    else if (warnCount > 0) wcagLevel = "AA";
    const totalChecks = Math.max(doc2.nodes.length * 3, 10);
    const passedChecks = Math.max(0, totalChecks - (errorCount + warnCount + infoCount));
    const scoreForCat = (item) => Math.max(0, Math.min(100, 100 - (item.errors * 20 + item.warns * 8 + item.infos * 2)));
    return {
      score,
      grade,
      wcagLevel,
      passedChecks,
      totalChecks,
      counts: { error: errorCount, warn: warnCount, info: infoCount },
      byCategory: {
        accessibility: {
          name: "Accessibility & WCAG",
          score: scoreForCat(cats.accessibility),
          ...cats.accessibility,
          passed: Math.max(0, doc2.nodes.length - cats.accessibility.errors - cats.accessibility.warns)
        },
        interaction: {
          name: "Mobile & Touch Targets",
          score: scoreForCat(cats.interaction),
          ...cats.interaction,
          passed: Math.max(0, doc2.nodes.length - cats.interaction.errors - cats.interaction.warns)
        },
        typography: {
          name: "Typography & Legibility",
          score: scoreForCat(cats.typography),
          ...cats.typography,
          passed: Math.max(0, doc2.nodes.length - cats.typography.errors - cats.typography.warns)
        },
        layout: {
          name: "Layout & Spacing Rhythm",
          score: scoreForCat(cats.layout),
          ...cats.layout,
          passed: Math.max(0, doc2.nodes.length - cats.layout.errors - cats.layout.warns)
        }
      }
    };
  }
  function indexNodes(doc2) {
    const m = /* @__PURE__ */ new Map();
    for (const n of doc2.nodes) m.set(n.id, n);
    return { byId: (id) => m.get(id) };
  }

  // packages/core/src/tokens.ts
  function rgbaToHex(c) {
    const h = (v) => Math.max(0, Math.min(255, Math.round(v * 255))).toString(16).padStart(2, "0");
    const base = `#${h(c.r)}${h(c.g)}${h(c.b)}`;
    return c.a < 0.999 ? `${base}${h(c.a)}` : base;
  }
  function luminance2(c) {
    const f = (u) => u <= 0.03928 ? u / 12.92 : Math.pow((u + 0.055) / 1.055, 2.4);
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function extractTokens(doc2) {
    const colorMap = /* @__PURE__ */ new Map();
    const registerColor = (c, role) => {
      if (!c || c.a <= 0.01) return;
      const hex = rgbaToHex(c);
      const existing = colorMap.get(hex);
      if (existing) {
        existing.count++;
        existing.roles.add(role);
      } else {
        colorMap.set(hex, { rgba: { ...c }, count: 1, roles: /* @__PURE__ */ new Set([role]) });
      }
    };
    if (doc2.rootBg) registerColor(doc2.rootBg, "background");
    const fontFamilies = /* @__PURE__ */ new Set();
    const fontSizes = /* @__PURE__ */ new Set();
    const fontWeights = /* @__PURE__ */ new Set();
    const lineHeights = /* @__PURE__ */ new Set();
    const spacings = /* @__PURE__ */ new Set();
    const radiiSet = /* @__PURE__ */ new Set();
    for (const n of doc2.nodes) {
      if (n.bgColor) registerColor(n.bgColor, "surface");
      if (n.textColor) registerColor(n.textColor, "text");
      if (n.border?.color) registerColor(n.border.color, "border");
      if (n.kind === "text") {
        if (n.fontFamily) fontFamilies.add(n.fontFamily);
        if (n.fontSize && n.fontSize > 0) fontSizes.add(Math.round(n.fontSize * 10) / 10);
        if (n.fontWeight) fontWeights.add(n.fontWeight);
        if (n.lineHeight && n.lineHeight > 0) lineHeights.add(Math.round(n.lineHeight * 10) / 10);
      }
      if (n.radii) {
        for (const r of n.radii) {
          if (r > 0) radiiSet.add(Math.round(r));
        }
      }
      if (n.w > 0 && n.w <= 128 && n.w % 4 === 0) spacings.add(n.w);
      if (n.h > 0 && n.h <= 128 && n.h % 4 === 0) spacings.add(n.h);
    }
    const sortedColors = [...colorMap.entries()].sort((a, b) => b[1].count - a[1].count).slice(0, 24);
    const colors = sortedColors.map(([hex, data], idx) => {
      let role = "surface";
      if (data.roles.has("text")) role = "text";
      else if (data.roles.has("border")) role = "border";
      else if (data.roles.has("background")) role = "background";
      const lum = luminance2(data.rgba);
      let name = `color-${idx + 1}`;
      if (role === "text") name = lum < 0.2 ? "color-text-primary" : "color-text-secondary";
      else if (role === "background") name = lum > 0.8 ? "color-bg-light" : "color-bg-dark";
      else if (role === "border") name = `color-border-${idx}`;
      else if (idx === 0) name = "color-primary";
      return {
        name,
        hex,
        rgba: data.rgba,
        role,
        count: data.count
      };
    });
    const commonSpacings = [4, 8, 12, 16, 20, 24, 32, 40, 48, 64].filter((s) => spacings.has(s));
    return {
      colors,
      typography: {
        fontFamilies: [...fontFamilies].sort(),
        fontSizeScale: [...fontSizes].sort((a, b) => a - b),
        fontWeights: [...fontWeights].sort((a, b) => a - b),
        lineHeights: [...lineHeights].sort((a, b) => a - b)
      },
      spacing: commonSpacings.length > 0 ? commonSpacings : [4, 8, 16, 24, 32],
      radii: [...radiiSet].sort((a, b) => a - b)
    };
  }
  function tokensToCss(tokens) {
    const lines = [":root {", "  /* Colors */"];
    tokens.colors.forEach((c) => {
      lines.push(`  --${c.name}: ${c.hex}; /* usage: ${c.count} */`);
    });
    lines.push("", "  /* Typography */");
    if (tokens.typography.fontFamilies.length) {
      lines.push(`  --font-family-base: ${tokens.typography.fontFamilies.join(", ")};`);
    }
    tokens.typography.fontSizeScale.forEach((fs, i) => {
      lines.push(`  --font-size-${i + 1}: ${fs}px;`);
    });
    lines.push("", "  /* Spacing */");
    tokens.spacing.forEach((s, i) => {
      lines.push(`  --space-${i + 1}: ${s}px;`);
    });
    if (tokens.radii.length) {
      lines.push("", "  /* Border Radii */");
      tokens.radii.forEach((r, i) => {
        lines.push(`  --radius-${i + 1}: ${r}px;`);
      });
    }
    lines.push("}");
    return lines.join("\n");
  }
  function tokensToDtcg(tokens) {
    const colorTokens = {};
    tokens.colors.forEach((c) => {
      colorTokens[c.name] = { $value: c.hex, $type: "color" };
    });
    const fontSizeTokens = {};
    tokens.typography.fontSizeScale.forEach((fs, i) => {
      fontSizeTokens[`step-${i + 1}`] = { $value: `${fs}px`, $type: "dimension" };
    });
    const spacingTokens = {};
    tokens.spacing.forEach((s, i) => {
      spacingTokens[`space-${i + 1}`] = { $value: `${s}px`, $type: "dimension" };
    });
    return {
      $version: "1.0",
      color: colorTokens,
      typography: {
        fontSize: fontSizeTokens
      },
      spacing: spacingTokens
    };
  }

  // packages/core/src/patch.ts
  function cssColor(c) {
    const hex = (v) => Math.max(0, Math.min(255, Math.round(v * 255))).toString(16).padStart(2, "0");
    return c.a >= 1 ? `#${hex(c.r)}${hex(c.g)}${hex(c.b)}` : `rgba(${Math.round(c.r * 255)}, ${Math.round(c.g * 255)}, ${Math.round(c.b * 255)}, ${Number(c.a.toFixed(3))})`;
  }
  function generateCssPatch(doc2, fixes) {
    const idx = indexNodes(doc2);
    const bySelector = /* @__PURE__ */ new Map();
    for (const f of fixes) {
      if (!f.nodeId) continue;
      const node = idx.byId(f.nodeId);
      if (!node) continue;
      const selector = node.provenance?.selector || (node.tag.toLowerCase() === "body" ? "body" : `${node.tag.toLowerCase()}[data-id="${node.id}"]`);
      let rule = bySelector.get(selector);
      if (!rule) {
        rule = {
          selector,
          declarations: [],
          nodeId: node.id,
          tag: node.tag.toLowerCase(),
          notes: []
        };
        bySelector.set(selector, rule);
      }
      switch (f.kind) {
        case "setTextColor":
          rule.declarations.push({ property: "color", value: cssColor(f.value) });
          rule.notes.push(`improve contrast against background`);
          break;
        case "setBackgroundColor":
          rule.declarations.push({ property: "background-color", value: cssColor(f.value) });
          rule.notes.push(`contrast background adjustment`);
          break;
        case "setFontSize":
          rule.declarations.push({ property: "font-size", value: `${f.value}px` });
          rule.notes.push(`consolidate font scale / legibility`);
          break;
        case "setSize":
          rule.declarations.push(
            { property: "min-width", value: `${f.w}px` },
            { property: "min-height", value: `${f.h}px` }
          );
          rule.notes.push(`ensure minimum touch target size (>=24x24px)`);
          break;
        case "setSnapY":
          rule.notes.push(`align Y coordinate to grid (${f.value}px)`);
          break;
      }
    }
    const lines = [
      `/* ========================================================================== */`,
      `/* uiuxaudit CSS Patch \u2014 ${doc2.slug} (${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}) */`,
      `/* Fixes: ${fixes.length} changes applied */`,
      `/* ========================================================================== */`,
      ``
    ];
    for (const [selector, rule] of bySelector) {
      if (!rule.declarations.length) continue;
      lines.push(`/* Node ${rule.nodeId} <${rule.tag}>: ${rule.notes.join("; ")} */`);
      lines.push(`${selector} {`);
      for (const d of rule.declarations) {
        lines.push(`  ${d.property}: ${d.value};`);
      }
      lines.push(`}`, ``);
    }
    return lines.join("\n");
  }

  // packages/core/src/report.ts
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function generateHtmlReport(doc2, suggestions2, providedScore, providedTokens) {
    const score = providedScore ?? calculateAuditScore(doc2, suggestions2);
    const tokens = providedTokens ?? extractTokens(doc2);
    const dateStr = (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
    const gradeColor = score.grade.startsWith("A") ? "#2ea86c" : score.grade === "B" ? "#4da3ff" : score.grade === "C" ? "#d9a03c" : "#e5534b";
    const colorSwatches = tokens.colors.map(
      (c) => `
      <div class="swatch-card">
        <div class="swatch-preview" style="background:${c.hex}"></div>
        <div class="swatch-info">
          <div class="swatch-name">${escapeHtml(c.name)}</div>
          <div class="swatch-hex">${escapeHtml(c.hex)}</div>
          <div class="swatch-role">${escapeHtml(c.role)} (${c.count}\xD7)</div>
        </div>
      </div>`
    ).join("");
    const issueCards = suggestions2.map((s, idx) => {
      const sevClass = s.severity;
      const targetStr = s.targetIds.length ? `Targets: ${s.targetIds.join(", ")}` : "Page level";
      const fixesSummary = s.fixes.map((f) => {
        switch (f.kind) {
          case "setTextColor":
            return `Set text color to rgba(${Math.round(f.value.r * 255)}, ${Math.round(f.value.g * 255)}, ${Math.round(f.value.b * 255)}, ${f.value.a})`;
          case "setBackgroundColor":
            return `Set bg color to rgba(${Math.round(f.value.r * 255)}, ${Math.round(f.value.g * 255)}, ${Math.round(f.value.b * 255)}, ${f.value.a})`;
          case "setFontSize":
            return `Set font-size to ${f.value}px`;
          case "setSize":
            return `Expand touch target to ${f.w}\xD7${f.h}px`;
          case "setSnapY":
            return `Snap Y coordinate to ${f.value}px`;
          default:
            return "";
        }
      }).filter(Boolean).join("; ");
      return `
      <div class="issue-card" data-severity="${s.severity}" data-rule="${s.rule}">
        <div class="issue-header">
          <span class="badge ${sevClass}">${s.severity.toUpperCase()}</span>
          <span class="issue-rule">${escapeHtml(s.rule)}</span>
          <span class="issue-id">${escapeHtml(s.id)}</span>
          <span class="spacer"></span>
          <span class="issue-targets">${escapeHtml(targetStr)}</span>
        </div>
        <div class="issue-message">${escapeHtml(s.message)}</div>
        ${fixesSummary ? `<div class="issue-fix"><strong>Recommended Fix:</strong> <code>${escapeHtml(fixesSummary)}</code></div>` : ""}
      </div>`;
    }).join("");
    return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>UI/UX Audit Report \u2014 ${escapeHtml(doc2.slug)}</title>
  <style>
    :root {
      --bg: #0e1116;
      --panel: #161b23;
      --panel-hover: #1c2430;
      --line: #232a35;
      --fg: #d7dde5;
      --dim: #8b95a3;
      --accent: #4da3ff;
      --ok: #2ea86c;
      --warn: #d9a03c;
      --err: #e5534b;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--fg);
      font: 14px/1.5 ui-sans-serif, system-ui, -apple-system, sans-serif;
      padding: 0;
    }
    .container {
      max-width: 1100px;
      margin: 0 auto;
      padding: 32px 24px;
    }
    header {
      border-bottom: 1px solid var(--line);
      padding-bottom: 24px;
      margin-bottom: 32px;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 16px;
    }
    h1 { margin: 0 0 6px 0; font-size: 26px; font-weight: 700; }
    .subtitle { color: var(--dim); font-size: 14px; }
    .scorecard {
      display: grid;
      grid-template-columns: 220px 1fr;
      gap: 24px;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 32px;
    }
    .score-circle-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      border-right: 1px solid var(--line);
      padding-right: 24px;
    }
    .big-score {
      font-size: 56px;
      font-weight: 800;
      line-height: 1;
      color: ${gradeColor};
    }
    .score-grade {
      font-size: 18px;
      font-weight: 700;
      color: var(--dim);
      margin-top: 4px;
    }
    .wcag-badge {
      display: inline-block;
      margin-top: 12px;
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 700;
      background: ${score.wcagLevel === "Non-compliant" ? "rgba(229,83,75,0.2)" : "rgba(46,168,108,0.2)"};
      color: ${score.wcagLevel === "Non-compliant" ? "var(--err)" : "var(--ok)"};
      border: 1px solid ${score.wcagLevel === "Non-compliant" ? "var(--err)" : "var(--ok)"};
    }
    .cat-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      align-content: center;
    }
    .cat-item {
      background: #11151c;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 12px 14px;
    }
    .cat-title { font-size: 12px; color: var(--dim); margin-bottom: 6px; }
    .cat-score { font-size: 20px; font-weight: 700; }
    .cat-meta { font-size: 11px; color: var(--dim); margin-top: 4px; }
    .cat-bar-wrap {
      background: var(--line);
      height: 4px;
      border-radius: 2px;
      margin-top: 8px;
      overflow: hidden;
    }
    .cat-bar-fill {
      height: 100%;
      border-radius: 2px;
      background: var(--accent);
    }
    .stats-summary {
      display: flex;
      gap: 12px;
      margin-bottom: 24px;
    }
    .stat-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 13px;
      background: var(--panel);
      border: 1px solid var(--line);
    }
    .badge {
      display: inline-block;
      padding: 2px 7px;
      border-radius: 99px;
      font-size: 10px;
      font-weight: 700;
    }
    .badge.error { background: #3a1715; color: #ff8f88; }
    .badge.warn { background: #392b12; color: #eec26a; }
    .badge.info { background: #14304a; color: #79bdff; }
    .toolbar {
      display: flex;
      gap: 12px;
      align-items: center;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .filter-btn {
      background: var(--panel);
      border: 1px solid var(--line);
      color: var(--fg);
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
    }
    .filter-btn.active {
      background: var(--accent);
      color: #06121f;
      border-color: var(--accent);
      font-weight: 600;
    }
    .search-box {
      flex: 1;
      min-width: 200px;
      padding: 7px 12px;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 6px;
      color: var(--fg);
      font-size: 13px;
    }
    .issue-card {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 16px;
      margin-bottom: 12px;
      transition: background 0.15s ease;
    }
    .issue-card:hover { background: var(--panel-hover); }
    .issue-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
    }
    .issue-rule { font-weight: 600; font-size: 13px; }
    .issue-id { color: var(--dim); font-size: 11px; font-family: monospace; }
    .issue-targets { color: var(--dim); font-size: 11px; }
    .issue-message { font-size: 13.5px; margin-bottom: 8px; }
    .issue-fix {
      font-size: 12px;
      background: #0d1218;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 8px 10px;
      color: var(--dim);
    }
    .issue-fix code { color: var(--accent); font-family: monospace; }
    .swatches-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
      gap: 12px;
      margin-top: 16px;
    }
    .swatch-card {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      overflow: hidden;
    }
    .swatch-preview { height: 50px; width: 100%; }
    .swatch-info { padding: 8px 10px; font-size: 11px; }
    .swatch-name { font-weight: 600; color: var(--fg); }
    .swatch-hex { color: var(--dim); font-family: monospace; }
    .swatch-role { color: var(--dim); font-size: 10px; margin-top: 2px; }
    .section-title {
      font-size: 18px;
      font-weight: 700;
      margin: 40px 0 16px 0;
      border-bottom: 1px solid var(--line);
      padding-bottom: 8px;
    }
    .spacer { flex: 1; }
    @media print {
      body { background: #fff; color: #111; }
      .scorecard, .issue-card, .swatch-card { border: 1px solid #ccc; background: #fff; color: #111; }
      .toolbar, .search-box { display: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div>
        <h1>UI/UX Audit Report</h1>
        <div class="subtitle">${escapeHtml(doc2.title || doc2.slug)} \xB7 <code>${escapeHtml(doc2.url)}</code> \xB7 Generated ${dateStr}</div>
      </div>
      <div>
        <div class="subtitle" style="text-align:right">Captured Nodes: <strong>${doc2.nodes.length}</strong></div>
        <div class="subtitle" style="text-align:right">Viewport: <strong>${doc2.viewportWidth}\xD7${doc2.viewportHeight}</strong></div>
      </div>
    </header>

    <div class="scorecard">
      <div class="score-circle-box">
        <div class="big-score">${score.score}</div>
        <div class="score-grade">Grade ${score.grade}</div>
        <span class="wcag-badge">${score.wcagLevel === "Non-compliant" ? "WCAG: Non-compliant" : "WCAG: " + score.wcagLevel}</span>
      </div>
      <div class="cat-grid">
        ${Object.values(score.byCategory).map(
      (cat) => `
          <div class="cat-item">
            <div class="cat-title">${escapeHtml(cat.name)}</div>
            <div class="cat-score">${cat.score}/100</div>
            <div class="cat-bar-wrap">
              <div class="cat-bar-fill" style="width:${cat.score}%; background:${cat.score > 85 ? "var(--ok)" : cat.score > 70 ? "var(--accent)" : "var(--warn)"}"></div>
            </div>
            <div class="cat-meta">${cat.errors} err \xB7 ${cat.warns} warn \xB7 ${cat.infos} info</div>
          </div>`
    ).join("")}
      </div>
    </div>

    <div class="stats-summary">
      <div class="stat-pill"><strong>Total Findings:</strong> ${suggestions2.length}</div>
      <div class="stat-pill"><span class="badge error">ERRORS</span> ${score.counts.error}</div>
      <div class="stat-pill"><span class="badge warn">WARNINGS</span> ${score.counts.warn}</div>
      <div class="stat-pill"><span class="badge info">INFO</span> ${score.counts.info}</div>
    </div>

    <div class="section-title">Audit Findings</div>

    <div class="toolbar">
      <button class="filter-btn active" data-filter="all">All (${suggestions2.length})</button>
      <button class="filter-btn" data-filter="error">Errors (${score.counts.error})</button>
      <button class="filter-btn" data-filter="warn">Warnings (${score.counts.warn})</button>
      <button class="filter-btn" data-filter="info">Info (${score.counts.info})</button>
      <input type="text" id="filterInput" class="search-box" placeholder="Search rules, messages, or elements\u2026" />
    </div>

    <div id="issuesContainer">
      ${issueCards || '<div class="subtitle">No findings detected. Document passed all rule checks.</div>'}
    </div>

    <div class="section-title">Extracted Design Tokens</div>
    <div class="subtitle">Detected color palette, hierarchy, and typography scale from the captured page.</div>
    <div class="swatches-grid">
      ${colorSwatches}
    </div>
  </div>

  <script>
    const btns = document.querySelectorAll(".filter-btn");
    const search = document.getElementById("filterInput");
    const cards = document.querySelectorAll(".issue-card");
    let currentFilter = "all";

    function update() {
      const q = (search.value || "").toLowerCase().trim();
      cards.forEach((c) => {
        const sev = c.dataset.severity;
        const text = c.textContent.toLowerCase();
        const matchesFilter = currentFilter === "all" || sev === currentFilter;
        const matchesSearch = !q || text.includes(q);
        c.style.display = matchesFilter && matchesSearch ? "" : "none";
      });
    }

    btns.forEach((b) => {
      b.addEventListener("click", () => {
        btns.forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        currentFilter = b.dataset.filter;
        update();
      });
    });

    search.addEventListener("input", update);
  <\/script>
</body>
</html>`;
  }

  // apps/web/src/main.ts
  var uaDesktop = globalThis.uaDesktop;
  var $ = (id) => {
    const el = document.getElementById(id);
    if (!el) throw new Error("missing #" + id);
    return el;
  };
  var meta = $("meta");
  var stage = $("stage");
  var stageToolbar = $("stageToolbar");
  var wrap = $("canvasWrap");
  var canvas = $("canvas");
  var dropHint = $("dropHint");
  var fileInput = $("file");
  var presetSelect = $("presetSelect");
  var verifyBtn = $("verifyBtn");
  var captureTabBtn = $("captureTabBtn");
  var list = $("suggList");
  var selCount = $("selCount");
  var selAll = $("selAll");
  var selNone = $("selNone");
  var applyBtn = $("applyBtn");
  var dlOps = $("dlOps");
  var dlApplied = $("dlApplied");
  var verifyPanel = $("verifyPanel");
  var tokInput = $("tok");
  var fkeyInput = $("fkey");
  var useAppliedCb = $("useApplied");
  var runVerifyBtn = $("runVerify");
  var verifyOut = $("verifyOut");
  var tokensBtn = $("tokensBtn");
  var reportBtn = $("reportBtn");
  var copyCssBtn = $("copyCssBtn");
  var copyOpsBtn = $("copyOpsBtn");
  var scorecardBar = $("scorecardBar");
  var scoreGauge = $("scoreGauge");
  var healthScoreNum = $("healthScoreNum");
  var healthScoreGrade = $("healthScoreGrade");
  var healthScoreWcag = $("healthScoreWcag");
  var btnFilterError = $("btnFilterError");
  var btnFilterWarn = $("btnFilterWarn");
  var btnFilterInfo = $("btnFilterInfo");
  var cntError = $("cntError");
  var cntWarn = $("cntWarn");
  var cntInfo = $("cntInfo");
  var catA11yVal = $("catA11yVal");
  var catA11yBar = $("catA11yBar");
  var catTouchVal = $("catTouchVal");
  var catTouchBar = $("catTouchBar");
  var catTypoVal = $("catTypoVal");
  var catTypoBar = $("catTypoBar");
  var catLayoutVal = $("catLayoutVal");
  var catLayoutBar = $("catLayoutBar");
  var btnViewOrig = $("btnViewOrig");
  var btnViewApplied = $("btnViewApplied");
  var toggleOverlays = $("toggleOverlays");
  var zoomOut = $("zoomOut");
  var zoomIn = $("zoomIn");
  var zoomReset = $("zoomReset");
  var zoomFit = $("zoomFit");
  var zoomLevel = $("zoomLevel");
  var nodeInspector = $("nodeInspector");
  var inspTag = $("inspTag");
  var inspId = $("inspId");
  var inspCoords = $("inspCoords");
  var inspStyles = $("inspStyles");
  var inspIssues = $("inspIssues");
  var closeInsp = $("closeInsp");
  var filterBar = $("filterBar");
  var suggFilter = $("suggFilter");
  var filterChips = document.querySelectorAll(".filter-chips-row .filter-chip");
  var tokensModal = $("tokensModal");
  var tokensBackdrop = $("tokensBackdrop");
  var closeTokensModal = $("closeTokensModal");
  var closeTokensFooter = $("closeTokensFooter");
  var tokenTabBody = $("tokenTabBody");
  var copyTokenCssBtn = $("copyTokenCssBtn");
  var copyTokenDtcgBtn = $("copyTokenDtcgBtn");
  var tabColors = $("tabColors");
  var tabTypo = $("tabTypo");
  var tabSpacing = $("tabSpacing");
  var tabCss = $("tabCss");
  var tabDtcg = $("tabDtcg");
  var doc = null;
  var appliedDoc = null;
  var suggestions = [];
  var auditScore = null;
  var designTokens = null;
  var checked = /* @__PURE__ */ new Set();
  var viewMode = "orig";
  var showOverlays = true;
  var zoomFactor = 1;
  var filterQuery = "";
  var filterSeverity = "all";
  var activeTokenTab = "colors";
  function toast(msg) {
    const existing = document.getElementById("toast");
    if (existing) existing.remove();
    const t = document.createElement("div");
    t.id = "toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2800);
  }
  function copyToClipboard(text, okMsg) {
    navigator.clipboard.writeText(text).then(
      () => toast(okMsg),
      () => toast("Failed to copy to clipboard")
    );
  }
  function download(name, data) {
    const content = typeof data === "string" ? data : JSON.stringify(data, null, 2);
    const mime = typeof data === "string" ? "text/html" : "application/json";
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4e3);
  }
  function cssColor2(c) {
    const h = (v) => Math.round(v * 255).toString(16).padStart(2, "0");
    return c.a >= 1 ? "#" + h(c.r) + h(c.g) + h(c.b) : `rgba(${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)},${c.a})`;
  }
  function updateScorecard() {
    if (!doc || !auditScore) {
      scorecardBar.hidden = true;
      return;
    }
    scorecardBar.hidden = false;
    healthScoreNum.textContent = String(auditScore.score);
    healthScoreGrade.textContent = `Grade ${auditScore.grade}`;
    healthScoreWcag.textContent = `WCAG: ${auditScore.wcagLevel}`;
    cntError.textContent = `${auditScore.counts.error} errors`;
    cntWarn.textContent = `${auditScore.counts.warn} warnings`;
    cntInfo.textContent = `${auditScore.counts.info} info`;
    const scoreColor = auditScore.score >= 90 ? "var(--color-success)" : auditScore.score >= 70 ? "var(--color-warn)" : "var(--color-error)";
    healthScoreNum.style.color = scoreColor;
    scoreGauge.style.borderColor = scoreColor;
    scoreGauge.style.boxShadow = `0 0 12px ${auditScore.score >= 90 ? "rgba(16, 185, 129, 0.3)" : auditScore.score >= 70 ? "rgba(245, 158, 11, 0.3)" : "rgba(239, 68, 68, 0.3)"}`;
    catA11yVal.textContent = `${auditScore.byCategory.accessibility.score}%`;
    catA11yBar.style.width = `${auditScore.byCategory.accessibility.score}%`;
    catTouchVal.textContent = `${auditScore.byCategory.interaction.score}%`;
    catTouchBar.style.width = `${auditScore.byCategory.interaction.score}%`;
    catTypoVal.textContent = `${auditScore.byCategory.typography.score}%`;
    catTypoBar.style.width = `${auditScore.byCategory.typography.score}%`;
    catLayoutVal.textContent = `${auditScore.byCategory.layout.score}%`;
    catLayoutBar.style.width = `${auditScore.byCategory.layout.score}%`;
  }
  async function loadFile(file) {
    try {
      const parsed = JSON.parse(await file.text());
      if (parsed?.version !== 1 || !Array.isArray(parsed.nodes)) {
        throw new Error("not a uiuxaudit capture (version/nodes missing)");
      }
      doc = parsed;
      appliedDoc = null;
      viewMode = "orig";
      btnViewOrig.classList.add("active");
      btnViewApplied.classList.remove("active");
      btnViewApplied.disabled = true;
      useAppliedCb.checked = false;
      useAppliedCb.disabled = true;
      suggestions = suggestFor(doc);
      auditScore = calculateAuditScore(doc, suggestions);
      designTokens = extractTokens(doc);
      checked.clear();
      meta.textContent = `${doc.slug} \xB7 ${doc.url || "local"} \xB7 ${doc.nodes.length} nodes \xB7 ${doc.docWidth}\xD7${doc.docHeight}`;
      stage.classList.add("hasdoc");
      stageToolbar.hidden = false;
      filterBar.hidden = false;
      verifyBtn.hidden = false;
      tokensBtn.hidden = false;
      reportBtn.hidden = false;
      copyCssBtn.hidden = false;
      copyOpsBtn.hidden = false;
      dlOps.hidden = true;
      dlApplied.hidden = true;
      updateScorecard();
      applyZoom();
      renderCanvas();
      renderSuggestions();
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e));
    }
  }
  fileInput.addEventListener("change", () => {
    const f = fileInput.files?.[0];
    if (f) void loadFile(f);
  });
  for (const ev of ["dragover", "dragenter"]) {
    stage.addEventListener(ev, (e) => {
      e.preventDefault();
      dropHint.classList.add("drag");
    });
  }
  for (const ev of ["dragleave", "drop"]) {
    stage.addEventListener(ev, (e) => {
      e.preventDefault();
      dropHint.classList.remove("drag");
    });
  }
  stage.addEventListener("drop", (e) => {
    const f = e.dataTransfer?.files?.[0];
    if (f) void loadFile(f);
  });
  var PRESETS = {
    example: {
      slug: "example",
      url: "https://example.com",
      title: "Example Domain",
      viewportWidth: 1440,
      viewportHeight: 900,
      docWidth: 1440,
      docHeight: 900,
      rootBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 },
      nodes: [
        { id: "e1", tag: "BODY", kind: "frame", x: 288, y: 135, w: 864, h: 96, parent: null, effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, opacity: 1, radii: [0, 0, 0, 0], interactive: false, bgColor: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, order: 0 },
        { id: "e2", tag: "H1", kind: "frame", x: 288, y: 135, w: 864, h: 28, parent: "e1", effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, opacity: 0.8, radii: [0, 0, 0, 0], interactive: false, order: 1 },
        { id: "e5", kind: "text", tag: "#text", x: 288, y: 135, w: 186, h: 28, text: "Example Domain", textColor: { r: 0, g: 0, b: 0, a: 1 }, effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, fontSize: 24, fontWeight: 700, fontFamily: "system-ui", textAlign: "LEFT", opacity: 0.8, order: 2, parent: "e2" },
        { id: "e3", tag: "P", kind: "frame", x: 288, y: 179, w: 864, h: 18, parent: "e1", effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, opacity: 0.8, radii: [0, 0, 0, 0], interactive: false, order: 3 },
        { id: "e6", kind: "text", tag: "#text", x: 288, y: 179, w: 746, h: 18, text: "This domain is for use in documentation examples without needing permission. Avoid use in operations.", textColor: { r: 0, g: 0, b: 0, a: 1 }, effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, fontSize: 16, fontWeight: 400, fontFamily: "system-ui", textAlign: "LEFT", opacity: 0.8, order: 4, parent: "e3" },
        { id: "e4", tag: "A", kind: "frame", x: 288, y: 213, w: 82, h: 18, parent: "e1", effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, opacity: 0.8, radii: [0, 0, 0, 0], interactive: true, order: 5 },
        { id: "e7", kind: "text", tag: "#text", x: 288, y: 213, w: 82, h: 18, text: "Learn more", textColor: { r: 0.2, g: 0.266, b: 0.533, a: 1 }, effectiveBg: { r: 0.933, g: 0.933, b: 0.933, a: 1 }, fontSize: 16, fontWeight: 400, fontFamily: "system-ui", textAlign: "LEFT", opacity: 0.8, order: 6, parent: "e4" }
      ]
    },
    saas: {
      slug: "saas",
      url: "https://app.cloudscale.io/dashboard",
      title: "CloudScale SaaS Analytics",
      viewportWidth: 1440,
      viewportHeight: 900,
      docWidth: 1440,
      docHeight: 900,
      rootBg: { r: 0.055, g: 0.067, b: 0.086, a: 1 },
      nodes: [
        { id: "s1", tag: "NAV", kind: "frame", x: 0, y: 0, w: 1440, h: 64, parent: null, bgColor: { r: 0.086, g: 0.106, b: 0.137, a: 1 }, effectiveBg: { r: 0.086, g: 0.106, b: 0.137, a: 1 }, order: 0 },
        { id: "s2", tag: "#text", kind: "text", x: 32, y: 20, w: 140, h: 24, text: "CloudScale UI", fontSize: 20, fontWeight: 700, textColor: { r: 0.9, g: 0.94, b: 1, a: 1 }, effectiveBg: { r: 0.086, g: 0.106, b: 0.137, a: 1 }, parent: "s1", order: 1 },
        { id: "s3", tag: "BUTTON", kind: "frame", x: 1320, y: 16, w: 88, h: 32, interactive: true, radii: [6, 6, 6, 6], bgColor: { r: 0.3, g: 0.64, b: 1, a: 1 }, effectiveBg: { r: 0.3, g: 0.64, b: 1, a: 1 }, parent: "s1", order: 2 },
        { id: "s4", tag: "#text", kind: "text", x: 1336, y: 22, w: 56, h: 20, text: "Deploy", fontSize: 14, fontWeight: 600, textColor: { r: 0.02, g: 0.07, b: 0.12, a: 1 }, effectiveBg: { r: 0.3, g: 0.64, b: 1, a: 1 }, parent: "s3", order: 3 },
        { id: "s5", tag: "DIV", kind: "frame", x: 64, y: 120, w: 400, h: 180, parent: null, bgColor: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, radii: [8, 8, 8, 8], order: 4 },
        { id: "s6", tag: "#text", kind: "text", x: 88, y: 144, w: 200, h: 16, text: "Total Workloads", fontSize: 13, fontWeight: 500, textColor: { r: 0.45, g: 0.48, b: 0.52, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, parent: "s5", order: 5 },
        { id: "s7", tag: "#text", kind: "text", x: 88, y: 172, w: 120, h: 44, text: "1,248", fontSize: 36, fontWeight: 800, textColor: { r: 1, g: 1, b: 1, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, parent: "s5", order: 6 },
        { id: "s8", tag: "DIV", kind: "frame", x: 500, y: 120, w: 400, h: 180, parent: null, bgColor: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, radii: [8, 8, 8, 8], order: 7 },
        { id: "s9", tag: "#text", kind: "text", x: 524, y: 144, w: 200, h: 16, text: "Bandwidth Used", fontSize: 13, fontWeight: 500, textColor: { r: 0.45, g: 0.48, b: 0.52, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, parent: "s8", order: 8 },
        { id: "s10", tag: "#text", kind: "text", x: 524, y: 172, w: 140, h: 44, text: "42.8 TB", fontSize: 36, fontWeight: 800, textColor: { r: 0.18, g: 0.66, b: 0.42, a: 1 }, effectiveBg: { r: 0.09, g: 0.11, b: 0.14, a: 1 }, parent: "s8", order: 9 }
      ]
    },
    mobile: {
      slug: "mobile",
      url: "https://m.walletflow.app/send",
      title: "WalletFlow Mobile Checkout",
      viewportWidth: 390,
      viewportHeight: 844,
      docWidth: 390,
      docHeight: 844,
      rootBg: { r: 0.07, g: 0.08, b: 0.1, a: 1 },
      nodes: [
        { id: "m1", tag: "HEADER", kind: "frame", x: 0, y: 0, w: 390, h: 60, parent: null, bgColor: { r: 0.1, g: 0.12, b: 0.15, a: 1 }, effectiveBg: { r: 0.1, g: 0.12, b: 0.15, a: 1 }, order: 0 },
        { id: "m2", tag: "#text", kind: "text", x: 20, y: 18, w: 120, h: 24, text: "Send Money", fontSize: 18, fontWeight: 700, textColor: { r: 1, g: 1, b: 1, a: 1 }, effectiveBg: { r: 0.1, g: 0.12, b: 0.15, a: 1 }, parent: "m1", order: 1 },
        { id: "m3", tag: "BUTTON", kind: "frame", x: 340, y: 22, w: 16, h: 16, interactive: true, parent: "m1", bgColor: { r: 0.2, g: 0.24, b: 0.3, a: 1 }, effectiveBg: { r: 0.1, g: 0.12, b: 0.15, a: 1 }, radii: [8, 8, 8, 8], order: 2 },
        { id: "m4", tag: "DIV", kind: "frame", x: 20, y: 100, w: 350, h: 90, parent: null, bgColor: { r: 0.12, g: 0.14, b: 0.18, a: 1 }, effectiveBg: { r: 0.12, g: 0.14, b: 0.18, a: 1 }, radii: [12, 12, 12, 12], order: 3 },
        { id: "m5", tag: "#text", kind: "text", x: 40, y: 120, w: 200, h: 16, text: "Transfer Amount", fontSize: 13, fontWeight: 500, textColor: { r: 0.5, g: 0.54, b: 0.6, a: 1 }, effectiveBg: { r: 0.12, g: 0.14, b: 0.18, a: 1 }, parent: "m4", order: 4 },
        { id: "m6", tag: "#text", kind: "text", x: 40, y: 144, w: 160, h: 32, text: "$250.00", fontSize: 26, fontWeight: 700, textColor: { r: 1, g: 1, b: 1, a: 1 }, effectiveBg: { r: 0.12, g: 0.14, b: 0.18, a: 1 }, parent: "m4", order: 5 },
        { id: "m7", tag: "BUTTON", kind: "frame", x: 20, y: 740, w: 350, h: 52, interactive: true, bgColor: { r: 0.3, g: 0.64, b: 1, a: 1 }, effectiveBg: { r: 0.3, g: 0.64, b: 1, a: 1 }, radii: [12, 12, 12, 12], order: 6 },
        { id: "m8", tag: "#text", kind: "text", x: 140, y: 755, w: 110, h: 22, text: "Confirm Send", fontSize: 16, fontWeight: 700, textColor: { r: 0.05, g: 0.08, b: 0.12, a: 1 }, effectiveBg: { r: 0.3, g: 0.64, b: 1, a: 1 }, parent: "m7", order: 7 }
      ]
    }
  };
  presetSelect.addEventListener("change", () => {
    const chosen = PRESETS[presetSelect.value];
    if (!chosen) return;
    const completeDoc = {
      version: 1,
      slug: chosen.slug ?? "preset",
      url: chosen.url ?? "https://example.com",
      title: chosen.title ?? "Preset",
      viewportWidth: chosen.viewportWidth ?? 1440,
      viewportHeight: chosen.viewportHeight ?? 900,
      docWidth: chosen.docWidth ?? 1440,
      docHeight: chosen.docHeight ?? 900,
      rootBg: chosen.rootBg,
      nodes: chosen.nodes ?? [],
      capturedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    void loadFile(
      new File([JSON.stringify(completeDoc)], `${completeDoc.slug}.capture.json`, {
        type: "application/json"
      })
    );
  });
  function applyZoom() {
    if (!doc) return;
    const fitScale = Math.min(1, (stage.clientWidth - 32) / doc.docWidth);
    const effective = fitScale * zoomFactor;
    wrap.style.transform = `scale(${effective})`;
    wrap.style.width = doc.docWidth + "px";
    wrap.style.height = doc.docHeight + "px";
    zoomLevel.textContent = `${Math.round(effective * 100)}%`;
  }
  zoomIn.addEventListener("click", () => {
    zoomFactor = Math.min(3, zoomFactor * 1.25);
    applyZoom();
  });
  zoomOut.addEventListener("click", () => {
    zoomFactor = Math.max(0.3, zoomFactor / 1.25);
    applyZoom();
  });
  zoomReset.addEventListener("click", () => {
    zoomFactor = 1;
    applyZoom();
  });
  zoomFit.addEventListener("click", () => {
    zoomFactor = 1;
    applyZoom();
  });
  btnViewOrig.addEventListener("click", () => {
    viewMode = "orig";
    btnViewOrig.classList.add("active");
    btnViewApplied.classList.remove("active");
    renderCanvas();
  });
  btnViewApplied.addEventListener("click", () => {
    if (!appliedDoc) return;
    viewMode = "applied";
    btnViewApplied.classList.add("active");
    btnViewOrig.classList.remove("active");
    renderCanvas();
  });
  toggleOverlays.addEventListener("change", () => {
    showOverlays = toggleOverlays.checked;
    renderCanvas();
  });
  var MAX_RENDERED_NODES = 8e3;
  function renderCanvas() {
    if (!doc) return;
    const activeDoc = viewMode === "applied" && appliedDoc ? appliedDoc : doc;
    canvas.textContent = "";
    const frag = document.createDocumentFragment();
    const nodes = activeDoc.nodes.slice(0, MAX_RENDERED_NODES);
    const touchMap = /* @__PURE__ */ new Set();
    const contrastMap = /* @__PURE__ */ new Map();
    for (const s of suggestions) {
      if (s.rule === "touch-target") {
        s.targetIds.forEach((id) => touchMap.add(id));
      } else if (s.rule === "contrast") {
        s.targetIds.forEach((id) => contrastMap.set(id, s));
      }
    }
    for (const n of nodes) {
      const el = document.createElement("div");
      el.className = "node" + (n.kind === "text" ? " text" : "");
      el.dataset["id"] = n.id;
      Object.assign(el.style, {
        left: n.x + "px",
        top: n.y + "px",
        width: Math.max(n.w, 1) + "px",
        height: Math.max(n.h, 1) + "px",
        opacity: String(n.opacity ?? 1)
      });
      if (n.kind === "text") {
        el.style.color = n.textColor ? cssColor2(n.textColor) : "#000";
        el.style.fontSize = (n.fontSize ?? 16) + "px";
        el.style.fontWeight = String(n.fontWeight ?? 400);
        el.style.lineHeight = n.lineHeight ? n.lineHeight + "px" : "normal";
        el.style.textAlign = (n.textAlign ?? "LEFT").toLowerCase() === "center" ? "center" : (n.textAlign ?? "").toLowerCase() === "right" ? "right" : "left";
        el.textContent = n.text ?? "";
      } else if (n.kind === "image") {
        el.style.background = n.imageDataUrl ? `center/cover no-repeat url("${n.imageDataUrl}")` : "#8a8f98";
      } else if (n.kind === "vector") {
        el.style.outline = "1px dashed #5a6472";
      } else {
        if (n.bgColor && n.bgColor.a > 0) el.style.background = cssColor2(n.bgColor);
        if (n.border && n.border.width > 0) {
          el.style.borderStyle = "solid";
          el.style.borderWidth = n.border.width + "px";
          el.style.borderColor = cssColor2(n.border.color);
        }
      }
      if (n.radii) {
        const [tl, tr, br, bl] = n.radii;
        el.style.borderRadius = `${tl}px ${tr}px ${br}px ${bl}px`;
      }
      if (showOverlays && viewMode === "orig") {
        if (touchMap.has(n.id) && (n.w < 24 || n.h < 24)) {
          const overlay = document.createElement("div");
          overlay.className = "touch-target-overlay";
          overlay.style.left = n.x + "px";
          overlay.style.top = n.y + "px";
          overlay.style.width = Math.max(n.w, 24) + "px";
          overlay.style.height = Math.max(n.h, 24) + "px";
          frag.appendChild(overlay);
        }
        if (contrastMap.has(n.id)) {
          const s = contrastMap.get(n.id);
          const pill = document.createElement("div");
          pill.className = "contrast-badge-pill";
          pill.style.left = n.x + "px";
          pill.style.top = n.y - 16 + "px";
          const m = s.message.match(/Contrast ([\d.]+):1/);
          pill.textContent = `Contrast ${m ? m[1] : "!<4.5"}`;
          frag.appendChild(pill);
        }
      }
      el.addEventListener("click", (ev) => {
        ev.stopPropagation();
        for (const hot of canvas.querySelectorAll(".hot")) hot.classList.remove("hot");
        el.classList.add("hot");
        renderInspector(n);
      });
      frag.appendChild(el);
    }
    canvas.appendChild(frag);
  }
  window.addEventListener("resize", () => {
    if (doc) applyZoom();
  });
  function renderInspector(n) {
    nodeInspector.hidden = false;
    inspTag.textContent = `<${n.tag.toLowerCase()}>`;
    inspId.textContent = n.id;
    inspCoords.textContent = `${Math.round(n.w)}\xD7${Math.round(n.h)}px @ (${Math.round(n.x)}, ${Math.round(n.y)})`;
    inspStyles.innerHTML = "";
    if (n.textColor) {
      inspStyles.innerHTML += `<div>Text: <span style="color:${cssColor2(n.textColor)}">\u25A0</span> ${cssColor2(n.textColor)}</div>`;
    }
    if (n.bgColor) {
      inspStyles.innerHTML += `<div>BG: <span style="color:${cssColor2(n.bgColor)}">\u25A0</span> ${cssColor2(n.bgColor)}</div>`;
    }
    if (n.fontSize) {
      inspStyles.innerHTML += `<div>Font: ${n.fontSize}px (${n.fontWeight ?? 400})</div>`;
    }
    const related = suggestions.filter((s) => s.targetIds.includes(n.id));
    inspIssues.innerHTML = "";
    if (!related.length) {
      inspIssues.innerHTML = '<div style="color:var(--dim)">No audit findings on this node.</div>';
    } else {
      related.forEach((s) => {
        const card = document.createElement("div");
        card.className = "insp-issue-item";
        card.innerHTML = `<strong>${s.rule}:</strong> ${s.message}`;
        if (s.fixes.length) {
          const fixBtn = document.createElement("button");
          fixBtn.className = "btn btn-sm insp-fix-btn";
          fixBtn.textContent = "Select Fix";
          fixBtn.addEventListener("click", () => {
            checked.add(s.id);
            updateCount();
            toast(`Selected fix ${s.id} for apply`);
          });
          card.appendChild(fixBtn);
        }
        inspIssues.appendChild(card);
      });
    }
  }
  closeInsp.addEventListener("click", () => {
    nodeInspector.hidden = true;
  });
  function severityChip(sev) {
    const chip = document.createElement("span");
    chip.className = "sev " + sev;
    chip.textContent = sev.toUpperCase();
    return chip;
  }
  function updateCount() {
    selCount.textContent = `${checked.size}/${suggestions.length} selected`;
    applyBtn.disabled = checked.size === 0;
    for (const li of list.children) {
      const cb = li.querySelector("input");
      if (cb && cb.dataset["sid"]) cb.checked = checked.has(cb.dataset["sid"]);
    }
  }
  function renderSuggestions() {
    list.textContent = "";
    const q = filterQuery.toLowerCase().trim();
    const filtered = suggestions.filter((s) => {
      const matchesSev = filterSeverity === "all" || s.severity === filterSeverity;
      const matchesQ = !q || s.rule.toLowerCase().includes(q) || s.message.toLowerCase().includes(q) || s.targetIds.some((t) => t.toLowerCase().includes(q));
      return matchesSev && matchesQ;
    });
    const frag = document.createDocumentFragment();
    filtered.forEach((s) => {
      const li = document.createElement("li");
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.disabled = s.fixes.length === 0;
      cb.dataset["sid"] = s.id;
      if (s.fixes.length === 0) cb.title = "report-only finding (no automated fix)";
      cb.addEventListener("change", () => {
        if (cb.checked) checked.add(s.id);
        else checked.delete(s.id);
        updateCount();
      });
      li.appendChild(cb);
      li.appendChild(severityChip(s.severity));
      const rule = document.createElement("span");
      rule.className = "rule";
      rule.textContent = s.rule;
      li.appendChild(rule);
      const msg = document.createElement("div");
      msg.className = "msg";
      msg.textContent = s.message + (s.fixes.length ? "" : " \xB7 report only");
      li.addEventListener("click", (e) => {
        if (e.target === cb) return;
        const target = doc?.nodes.find((n) => n.id === s.targetIds[0]);
        if (!target) return;
        for (const hot of canvas.querySelectorAll(".hot")) hot.classList.remove("hot");
        const el = canvas.querySelector(`[data-id="${target.id}"]`);
        if (el) {
          el.classList.add("hot");
          el.scrollIntoView({ block: "nearest", behavior: "smooth" });
          renderInspector(target);
        }
      });
      li.appendChild(msg);
      if (checked.has(s.id)) cb.checked = true;
      frag.appendChild(li);
    });
    list.appendChild(frag);
    updateCount();
  }
  function setSeverityFilter(sev) {
    filterSeverity = sev;
    filterChips.forEach((b) => {
      if (b.dataset["sev"] === sev) b.classList.add("active");
      else b.classList.remove("active");
    });
    renderSuggestions();
  }
  btnFilterError.addEventListener(
    "click",
    () => setSeverityFilter(filterSeverity === "error" ? "all" : "error")
  );
  btnFilterWarn.addEventListener(
    "click",
    () => setSeverityFilter(filterSeverity === "warn" ? "all" : "warn")
  );
  btnFilterInfo.addEventListener(
    "click",
    () => setSeverityFilter(filterSeverity === "info" ? "all" : "info")
  );
  suggFilter.addEventListener("input", () => {
    filterQuery = suggFilter.value;
    renderSuggestions();
  });
  filterChips.forEach((btn) => {
    btn.addEventListener("click", () => {
      const sev = btn.dataset["sev"] ?? "all";
      setSeverityFilter(sev);
    });
  });
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (!tokensModal.hidden) closeTokens();
      if (!nodeInspector.hidden) nodeInspector.hidden = true;
    }
  });
  selAll.addEventListener("click", () => {
    for (const s of suggestions) if (s.fixes.length) checked.add(s.id);
    updateCount();
  });
  selNone.addEventListener("click", () => {
    checked.clear();
    updateCount();
  });
  applyBtn.addEventListener("click", () => {
    if (!doc) return;
    const chosen = suggestions.filter((s) => checked.has(s.id));
    const fixes = chosen.flatMap((s) => s.fixes);
    if (!fixes.length) {
      toast("selected findings carry no automated fixes");
      return;
    }
    const ops = fixesToFigmaOps(fixes);
    appliedDoc = applyFixesToDoc(doc, fixes);
    download(`${doc.slug}.ops.json`, { slug: doc.slug, ops });
    download(`${doc.slug}.applied.capture.json`, appliedDoc);
    dlOps.href = URL.createObjectURL(
      new Blob([JSON.stringify({ slug: doc.slug, ops }, null, 2)], { type: "application/json" })
    );
    dlApplied.href = URL.createObjectURL(
      new Blob([JSON.stringify(appliedDoc, null, 2)], { type: "application/json" })
    );
    dlOps.hidden = false;
    dlApplied.hidden = false;
    useAppliedCb.disabled = false;
    useAppliedCb.checked = true;
    btnViewApplied.disabled = false;
    btnViewApplied.click();
    toast(`${ops.length} ops applied! Showing live Applied Preview`);
  });
  reportBtn.addEventListener("click", () => {
    if (!doc) return;
    const reportHtml = generateHtmlReport(doc, suggestions, auditScore ?? void 0, designTokens ?? void 0);
    download(`${doc.slug}.report.html`, reportHtml);
    toast(`Exported HTML audit report for ${doc.slug}!`);
  });
  copyCssBtn.addEventListener("click", () => {
    if (!doc) return;
    const chosen = suggestions.filter((s) => checked.has(s.id));
    const fixes = (chosen.length ? chosen : suggestions).flatMap((s) => s.fixes);
    if (!fixes.length) {
      toast("No fixes to generate CSS for");
      return;
    }
    const css = generateCssPatch(doc, fixes);
    copyToClipboard(css, `Copied ${fixes.length} CSS fix declarations!`);
  });
  copyOpsBtn.addEventListener("click", () => {
    if (!doc) return;
    const chosen = suggestions.filter((s) => checked.has(s.id));
    const fixes = (chosen.length ? chosen : suggestions).flatMap((s) => s.fixes);
    const ops = fixesToFigmaOps(fixes);
    copyToClipboard(JSON.stringify({ slug: doc.slug, ops }, null, 2), `Copied ${ops.length} Figma Ops JSON!`);
  });
  tokensBtn.addEventListener("click", () => {
    if (!designTokens) return;
    tokensModal.hidden = false;
    renderTokenTab();
  });
  var closeTokens = () => {
    tokensModal.hidden = true;
  };
  closeTokensModal.addEventListener("click", closeTokens);
  closeTokensFooter.addEventListener("click", closeTokens);
  tokensBackdrop.addEventListener("click", closeTokens);
  function renderTokenTab() {
    if (!designTokens) return;
    tokenTabBody.innerHTML = "";
    if (activeTokenTab === "colors") {
      const grid = document.createElement("div");
      grid.className = "token-grid";
      designTokens.colors.forEach((c) => {
        const card = document.createElement("div");
        card.className = "token-card";
        card.innerHTML = `
        <div class="token-swatch" style="background:${c.hex}"></div>
        <div class="token-info">
          <div><strong>${c.name}</strong></div>
          <div style="font-family:monospace;color:var(--dim)">${c.hex}</div>
          <div style="font-size:10px;color:var(--dim)">${c.role} (${c.count}\xD7)</div>
        </div>
      `;
        grid.appendChild(card);
      });
      tokenTabBody.appendChild(grid);
    } else if (activeTokenTab === "typo") {
      const pre = document.createElement("div");
      pre.className = "token-code";
      pre.textContent = JSON.stringify(designTokens.typography, null, 2);
      tokenTabBody.appendChild(pre);
    } else if (activeTokenTab === "spacing") {
      const pre = document.createElement("div");
      pre.className = "token-code";
      pre.textContent = JSON.stringify({ spacing: designTokens.spacing, radii: designTokens.radii }, null, 2);
      tokenTabBody.appendChild(pre);
    } else if (activeTokenTab === "css") {
      const pre = document.createElement("div");
      pre.className = "token-code";
      pre.textContent = tokensToCss(designTokens);
      tokenTabBody.appendChild(pre);
    } else if (activeTokenTab === "dtcg") {
      const pre = document.createElement("div");
      pre.className = "token-code";
      pre.textContent = JSON.stringify(tokensToDtcg(designTokens), null, 2);
      tokenTabBody.appendChild(pre);
    }
  }
  var tabBtns = [tabColors, tabTypo, tabSpacing, tabCss, tabDtcg];
  var tabKeys = ["colors", "typo", "spacing", "css", "dtcg"];
  tabBtns.forEach((b, i) => {
    b.addEventListener("click", () => {
      tabBtns.forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      activeTokenTab = tabKeys[i];
      renderTokenTab();
    });
  });
  copyTokenCssBtn.addEventListener("click", () => {
    if (!designTokens) return;
    copyToClipboard(tokensToCss(designTokens), "Copied CSS Custom Properties to clipboard!");
  });
  copyTokenDtcgBtn.addEventListener("click", () => {
    if (!designTokens) return;
    copyToClipboard(JSON.stringify(tokensToDtcg(designTokens), null, 2), "Copied DTCG tokens JSON!");
  });
  var LS_TOK = "ua.token";
  var LS_KEY = "ua.filekey";
  tokInput.value = localStorage.getItem(LS_TOK) ?? "";
  fkeyInput.value = localStorage.getItem(LS_KEY) ?? "";
  verifyBtn.addEventListener("click", () => {
    verifyPanel.hidden = !verifyPanel.hidden;
  });
  runVerifyBtn.addEventListener("click", async () => {
    if (!doc) {
      toast("load a capture first");
      return;
    }
    const token = tokInput.value.trim();
    const fileKey = fkeyInput.value.trim().match(/([A-Za-z0-9]{6,})\s*$/)?.[1] ?? fkeyInput.value.trim();
    if (!token || !fileKey) {
      toast("token and file key required");
      return;
    }
    localStorage.setItem(LS_TOK, token);
    localStorage.setItem(LS_KEY, fileKey);
    const baseline = useAppliedCb.checked && appliedDoc ? appliedDoc : doc;
    runVerifyBtn.disabled = true;
    verifyOut.textContent = `verifying ${baseline.slug} vs ${useAppliedCb.checked && appliedDoc ? "applied" : "original"} baseline\u2026`;
    try {
      let report;
      if (uaDesktop) {
        const r = await uaDesktop.verify({ token, fileKey, capture: baseline });
        if (!r.ok || !r.report) throw new Error(r.error ?? "bridge verify failed");
        report = r.report;
      } else {
        report = await verifyCapture({ token, fileKey, capture: baseline });
      }
      const badge = document.createElement("span");
      badge.className = "badge " + (report.passed ? "pass" : "fail");
      badge.textContent = report.passed ? "PASS" : "FAIL";
      const lines = [
        `coverage ${(report.coverage * 100).toFixed(2)}% (${report.found}/${report.total})`,
        `mismatches: ${report.mismatches.length}`,
        ...report.mismatches.slice(0, 30).map(
          (m) => `${m.id.padEnd(8)} ${m.field.padEnd(11)} expected=${m.expected} actual=${m.actual}` + (m.delta !== void 0 ? ` \u0394=${m.delta}` : "")
        ),
        ...report.mismatches.length > 30 ? [`\u2026 +${report.mismatches.length - 30} more`] : []
      ];
      verifyOut.textContent = "";
      verifyOut.appendChild(badge);
      verifyOut.appendChild(document.createTextNode("\n" + lines.join("\n")));
    } catch (e) {
      verifyOut.textContent = "verify failed: " + (e instanceof Error ? e.message : String(e));
    } finally {
      runVerifyBtn.disabled = false;
    }
  });
  window["__ua"] = {
    loadJSON(text) {
      return loadFile(new File([text], "smoke.capture.json", { type: "application/json" }));
    }
  };
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    navigator.serviceWorker.register("./sw.js").catch(() => {
    });
  }
  var extGlobal = globalThis;
  var extRuntime = extGlobal.chrome?.runtime;
  if (extRuntime?.id && typeof extRuntime.sendMessage === "function") {
    captureTabBtn.hidden = false;
    captureTabBtn.addEventListener("click", () => {
      captureTabBtn.disabled = true;
      extRuntime.sendMessage({ type: "CAPTURE_TAB" }, (resp) => {
        captureTabBtn.disabled = false;
        const err = extRuntime.lastError?.message ?? resp?.error;
        if (err || !resp?.ok || !resp.doc) {
          toast("capture failed: " + (err ?? "unknown"));
          return;
        }
        void loadFile(
          new File([JSON.stringify(resp.doc)], (resp.doc.slug || "tab") + ".capture.json", {
            type: "application/json"
          })
        );
      });
    });
  }
  var convUrlInput = $("convUrl");
  var convBtn = $("convBtn");
  if (uaDesktop) {
    void uaDesktop.chromiumPath?.().then((r) => {
      if (!r.ok) toast("convert disabled \u2014 " + r.error);
    });
  }
  var runConvert = async () => {
    const url = convUrlInput.value.trim();
    if (!/^https?:\/\//i.test(url)) {
      toast("Please enter a valid http(s) URL");
      return;
    }
    convBtn.disabled = true;
    const btnText = convBtn.querySelector(".btn-text");
    const origText = btnText ? btnText.textContent : convBtn.textContent;
    if (btnText) btnText.textContent = "Capturing\u2026";
    else convBtn.textContent = "Capturing\u2026";
    try {
      if (uaDesktop) {
        const r = await uaDesktop.convert({ url });
        if (!r.ok || !r.doc) throw new Error(r.error ?? "Desktop capture failed");
        await loadFile(
          new File([JSON.stringify(r.doc)], (r.doc.slug || "page") + ".capture.json", {
            type: "application/json"
          })
        );
        toast(`Captured ${url} successfully!`);
      } else {
        const res = await fetch("/api/convert", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ url })
        }).catch(() => null);
        if (!res) {
          throw new Error(
            "Direct URL conversion requires local GUI server. Run 'npx uiuxaudit gui' or use desktop app."
          );
        }
        if (!res.ok) {
          if (res.status === 404) {
            throw new Error(
              "Direct URL conversion requires local GUI server. Run 'npx uiuxaudit gui' or use desktop app."
            );
          }
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error ?? `Capture failed with status ${res.status}`);
        }
        const data = await res.json();
        if (!data.ok || !data.doc) throw new Error(data.error ?? "Invalid capture response");
        await loadFile(
          new File([JSON.stringify(data.doc)], (data.doc.slug || "page") + ".capture.json", {
            type: "application/json"
          })
        );
        toast(`Captured ${url} successfully!`);
      }
    } catch (err) {
      toast(err instanceof Error ? err.message : String(err));
    } finally {
      convBtn.disabled = false;
      if (btnText) btnText.textContent = origText;
      else convBtn.textContent = origText;
    }
  };
  convBtn.addEventListener("click", () => void runConvert());
  convUrlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") void runConvert();
  });
})();
