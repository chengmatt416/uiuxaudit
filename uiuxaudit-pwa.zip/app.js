"use strict";
(() => {
  // packages/core/src/verify.ts
  var POS_TOLERANCE_PX = 2;
  var COLOR_TOLERANCE = 3 / 255;
  var ALPHA_TOLERANCE = 0.02;
  var FONT_SIZE_TOLERANCE = 0.51;
  async function figmaGet(path, token) {
    const res = await fetch(`https://api.figma.com/v1/${path}`, {
      headers: { "X-Figma-Token": token },
      signal: AbortSignal.timeout(6e4)
    });
    if (!res.ok) {
      throw new Error(
        `Figma API ${res.status} for /${path}: ${(await res.text()).slice(0, 300)}`
      );
    }
    return await res.json();
  }
  function walk(node, out) {
    out.set(node.name, node);
    for (const c of node.children ?? []) walk(c, out);
  }
  function firstSolidPaint(node) {
    for (const p of node.fills ?? []) {
      if (p.type === "SOLID" && p.visible !== false && p.color && (p.opacity ?? 1) > 0) {
        return p;
      }
    }
    return void 0;
  }
  function colorMatches(paint, expected) {
    if (!paint?.color) return false;
    const o = paint.opacity ?? 1;
    return Math.abs(paint.color.r - expected.r) <= COLOR_TOLERANCE && Math.abs(paint.color.g - expected.g) <= COLOR_TOLERANCE && Math.abs(paint.color.b - expected.b) <= COLOR_TOLERANCE && (expected.a >= 1 ? o >= 1 - ALPHA_TOLERANCE : Math.abs(o - expected.a) <= ALPHA_TOLERANCE);
  }
  function norm(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  async function verifyCapture(opts) {
    const { token, fileKey, capture } = opts;
    const rootName = `page:${capture.slug}`;
    const file = await figmaGet(
      `files/${fileKey}?depth=3`,
      token
    );
    let rootId;
    for (const page of file.document.children ?? []) {
      for (const child of page.children ?? []) {
        if (child.name === rootName) {
          rootId = child.id;
          break;
        }
      }
      if (rootId) break;
    }
    if (!rootId) {
      throw new Error(
        `Frame "${rootName}" not found in file ${fileKey}. Import the capture first.`
      );
    }
    const detail = await figmaGet(
      `files/${fileKey}/nodes?ids=${rootId}&geometry=absolute_bounding_box`,
      token
    );
    const subtree = detail.nodes[rootId]?.document;
    if (!subtree) throw new Error(`Figma returned no subtree for node ${rootId}`);
    const byName = /* @__PURE__ */ new Map();
    walk(subtree, byName);
    const mismatches = [];
    let found = 0;
    for (const cap of capture.nodes) {
      const node = byName.get(cap.id);
      if (!node) {
        mismatches.push({
          id: cap.id,
          field: "missing",
          expected: `${cap.kind} @(${cap.x},${cap.y})`,
          actual: "absent"
        });
        continue;
      }
      found++;
      const bb = node.absoluteBoundingBox;
      if (!bb) {
        mismatches.push({ id: cap.id, field: "missing", expected: "bbox", actual: "none" });
        continue;
      }
      const checks = [
        ["x", bb.x, cap.x],
        ["y", bb.y, cap.y],
        ["w", bb.width, cap.w],
        ["h", bb.height, cap.h]
      ];
      for (const [field, actual, expected] of checks) {
        const delta = Math.abs(actual - expected);
        if (delta > POS_TOLERANCE_PX) {
          mismatches.push({
            id: cap.id,
            field,
            expected: String(Number(expected.toFixed(2))),
            actual: String(Number(actual.toFixed(2))),
            delta: Number(delta.toFixed(2))
          });
        }
      }
      if (cap.bgColor && cap.bgColor.a > 0) {
        const p = firstSolidPaint(node);
        if (!colorMatches(p, cap.bgColor)) {
          mismatches.push({
            id: cap.id,
            field: "bgColor",
            expected: JSON.stringify(cap.bgColor),
            actual: p ? JSON.stringify(p.color) + "@" + (p.opacity ?? 1) : "none"
          });
        }
      }
      if (cap.kind === "text") {
        if (cap.textColor && cap.textColor.a > 0) {
          const p = firstSolidPaint(node);
          if (!colorMatches(p, cap.textColor)) {
            mismatches.push({
              id: cap.id,
              field: "textColor",
              expected: JSON.stringify(cap.textColor),
              actual: p ? JSON.stringify(p.color) + "@" + (p.opacity ?? 1) : "none"
            });
          }
        }
        if (cap.fontSize && node.fontSize) {
          if (Math.abs(node.fontSize - cap.fontSize) > FONT_SIZE_TOLERANCE) {
            mismatches.push({
              id: cap.id,
              field: "fontSize",
              expected: String(cap.fontSize),
              actual: String(node.fontSize)
            });
          }
        }
        if (cap.text && node.characters !== void 0) {
          if (norm(node.characters) !== norm(cap.text)) {
            mismatches.push({
              id: cap.id,
              field: "characters",
              expected: cap.text.slice(0, 60),
              actual: node.characters.slice(0, 60)
            });
          }
        }
      }
    }
    const coverage = capture.nodes.length ? found / capture.nodes.length : 1;
    return {
      slug: capture.slug,
      fileKey,
      total: capture.nodes.length,
      found,
      coverage,
      passed: coverage >= 0.95 && mismatches.length === 0,
      mismatches,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // packages/core/src/apply.ts
  function applyFixesToDoc(doc2, fixes) {
    const nodes = doc2.nodes.map((n) => ({ ...n }));
    const byId = /* @__PURE__ */ new Map();
    for (const n of nodes) byId.set(n.id, n);
    for (const f of fixes) {
      if (!f.nodeId) continue;
      const n = byId.get(f.nodeId);
      if (!n) continue;
      switch (f.kind) {
        case "setTextColor":
          n.textColor = { ...f.value };
          break;
        case "setBackgroundColor":
          n.bgColor = { ...f.value };
          break;
        case "setFontSize":
          n.fontSize = f.value;
          break;
        case "setSize":
          n.w = f.w;
          n.h = f.h;
          break;
        case "setSnapY":
          n.y = f.value;
          break;
      }
    }
    return { ...doc2, nodes, capturedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  function fixesToFigmaOps(fixes) {
    const ops = [];
    for (const f of fixes) {
      switch (f.kind) {
        case "setTextColor":
          ops.push({ id: f.nodeId, op: "setFill", value: f.value });
          break;
        case "setBackgroundColor":
          ops.push({ id: f.nodeId, op: "setBackground", value: f.value });
          break;
        case "setFontSize":
          ops.push({ id: f.nodeId, op: "setFontSize", value: f.value });
          break;
        case "setSize":
          ops.push({ id: f.nodeId, op: "setSize", w: f.w, h: f.h });
          break;
        case "setSnapY":
          ops.push({ id: f.nodeId, op: "setSnapY", value: f.value });
          break;
      }
    }
    return ops;
  }

  // packages/core/src/suggest.ts
  function srgbLinear(u) {
    return u <= 0.03928 ? u / 12.92 : Math.pow((u + 0.055) / 1.055, 2.4);
  }
  function luminance(c) {
    return 0.2126 * srgbLinear(c.r) + 0.7152 * srgbLinear(c.g) + 0.0722 * srgbLinear(c.b);
  }
  function contrastRatio(a, b) {
    const l1 = luminance(a);
    const l2 = luminance(b);
    const hi = Math.max(l1, l2);
    const lo = Math.min(l1, l2);
    return (hi + 0.05) / (lo + 0.05);
  }
  var BLACK = { r: 0, g: 0, b: 0, a: 1 };
  var WHITE = { r: 1, g: 1, b: 1, a: 1 };
  function blendToward(c, target, f) {
    return {
      r: round4(c.r + (target.r - c.r) * f),
      g: round4(c.g + (target.g - c.g) * f),
      b: round4(c.b + (target.b - c.b) * f),
      a: c.a
    };
  }
  function round4(n) {
    return Math.round(n * 1e4) / 1e4;
  }
  function adjustForContrast(fg, bg, targetRatio) {
    let bestF = Infinity;
    let bestC = null;
    for (const t of [BLACK, WHITE]) {
      if (contrastRatio(blendToward(fg, t, 1), bg) < targetRatio) continue;
      let lo = 0;
      let hi = 1;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (contrastRatio(blendToward(fg, t, mid), bg) >= targetRatio) hi = mid;
        else lo = mid;
      }
      if (hi < bestF) {
        bestF = hi;
        bestC = blendToward(fg, t, hi);
      }
    }
    if (!bestC) return null;
    const quantize = (c) => ({
      r: Math.round(c.r * 255) / 255,
      g: Math.round(c.g * 255) / 255,
      b: Math.round(c.b * 255) / 255,
      a: c.a
    });
    const darker = bestC.r + bestC.g + bestC.b <= fg.r + fg.g + fg.b;
    const extreme = darker ? BLACK : WHITE;
    for (let k = 0; k < 16; k++) {
      const cand = quantize(
        blendToward(fg, extreme, Math.min(1, bestF + k / 255))
      );
      if (contrastRatio(cand, bg) >= targetRatio) return cand;
    }
    return quantize(bestC);
  }
  var SEVERITY_RANK = { error: 0, warn: 1, info: 2 };
  function suggestFor(doc2, limit = 300) {
    const raw = [];
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.textColor || !n.fontSize) continue;
      const bg = n.effectiveBg ?? doc2.rootBg ?? WHITE;
      const large = n.fontSize >= 24 || n.fontSize >= 18.66 && (n.fontWeight ?? 400) >= 700;
      const target = large ? 3 : 4.5;
      const ratio = contrastRatio(n.textColor, bg);
      if (ratio >= target - 1e-9) continue;
      const fixed = adjustForContrast(n.textColor, bg, target);
      raw.push({
        rule: "contrast",
        severity: ratio < target / 2 ? "error" : "warn",
        message: `Contrast ${ratio.toFixed(2)}:1 < ${target}:1 for ${n.fontSize.toFixed(1)}px "${(n.text ?? "").trim().slice(0, 40)}"`,
        targetIds: [n.id],
        fixes: fixed ? [{ kind: "setTextColor", nodeId: n.id, value: fixed }] : []
      });
    }
    for (const n of doc2.nodes) {
      if (!n.interactive || n.kind === "text") continue;
      if (n.w >= 24 && n.h >= 24) continue;
      raw.push({
        rule: "touch-target",
        severity: "warn",
        message: `<${n.tag.toLowerCase()}> ${n.w.toFixed(0)}x${n.h.toFixed(0)}px below 24x24px minimum`,
        targetIds: [n.id],
        fixes: [
          {
            kind: "setSize",
            nodeId: n.id,
            w: Math.max(n.w, 24),
            h: Math.max(n.h, 24)
          }
        ]
      });
    }
    const freqKey = (fs) => Math.round(fs * 2) / 2;
    const freq = /* @__PURE__ */ new Map();
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.fontSize) continue;
      const k = freqKey(n.fontSize);
      freq.set(k, (freq.get(k) ?? 0) + 1);
    }
    const distinct = [...freq.keys()].sort((a, b) => a - b);
    if (distinct.length > 6) {
      const kept = [...freq.entries()].sort((a, b) => b[1] - a[1] || a[0] - b[0]).slice(0, 4).map((e) => e[0]).sort((a, b) => a - b);
      const fixes = [];
      const targetIds = [];
      for (const n of doc2.nodes) {
        if (n.kind !== "text" || !n.fontSize) continue;
        const k = freqKey(n.fontSize);
        if (kept.includes(k)) continue;
        const nearest = kept.reduce(
          (best, cur) => Math.abs(cur - k) < Math.abs(best - k) ? cur : best
        );
        if (nearest === k) continue;
        targetIds.push(n.id);
        fixes.push({ kind: "setFontSize", nodeId: n.id, value: nearest });
      }
      if (fixes.length) {
        raw.push({
          rule: "font-scale",
          severity: "info",
          message: `${distinct.length} distinct font sizes; consolidate outliers onto scale ${kept.join("/")}px (${fixes.length} nodes)`,
          targetIds,
          fixes
        });
      }
    }
    for (const n of doc2.nodes) {
      if (n.kind !== "text" || !n.fontSize || (n.fontSize ?? 16) < 12) continue;
      const estCharsPerLine = n.w / (n.fontSize * 0.5);
      if (estCharsPerLine <= 100) continue;
      raw.push({
        rule: "line-length",
        severity: "info",
        message: `Text block spans ~${estCharsPerLine.toFixed(0)} em-halved characters per line (>100); consider constraining measure`,
        targetIds: [n.id],
        fixes: []
      });
    }
    raw.sort(
      (a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || (a.targetIds[0] ?? "").localeCompare(
        (b.targetIds[0] ?? "") || "",
        void 0,
        { numeric: true }
      ) || a.rule.localeCompare(b.rule)
    );
    const truncated = raw.length > limit;
    const picked = raw.slice(0, limit).map((s, i) => ({
      ...s,
      id: "s" + String(i + 1).padStart(3, "0")
    }));
    if (truncated) {
      picked.push({
        id: "s" + String(picked.length + 1).padStart(3, "0"),
        rule: "contrast",
        severity: "info",
        message: `(+${raw.length - limit} further findings truncated deterministically)`,
        targetIds: [],
        fixes: []
      });
    }
    return picked;
  }

  // apps/web/src/main.ts
  var uaDesktop = globalThis.uaDesktop;
  var $ = (id) => {
    const el = document.getElementById(id);
    if (!el) throw new Error("missing #" + id);
    return el;
  };
  var meta = $("meta");
  var stage = $("stage");
  var wrap = $("canvasWrap");
  var canvas = $("canvas");
  var dropHint = $("dropHint");
  var fileInput = $("file");
  var verifyBtn = $("verifyBtn");
  var captureTabBtn = $("captureTabBtn");
  var list = $("suggList");
  var selCount = $("selCount");
  var selAll = $("selAll");
  var selNone = $("selNone");
  var applyBtn = $("applyBtn");
  var dlOps = $("dlOps");
  var dlApplied = $("dlApplied");
  var verifyPanel = $("verifyPanel");
  var tokInput = $("tok");
  var fkeyInput = $("fkey");
  var useAppliedCb = $("useApplied");
  var runVerifyBtn = $("runVerify");
  var verifyOut = $("verifyOut");
  var doc = null;
  var appliedDoc = null;
  var suggestions = [];
  var checked = /* @__PURE__ */ new Set();
  function toast(msg) {
    const t = document.createElement("div");
    t.id = "toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }
  function download(name, data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4e3);
  }
  async function loadFile(file) {
    try {
      const parsed = JSON.parse(await file.text());
      if (parsed?.version !== 1 || !Array.isArray(parsed.nodes)) {
        throw new Error("not a uiuxaudit capture (version/nodes missing)");
      }
      doc = parsed;
      appliedDoc = null;
      useAppliedCb.checked = false;
      useAppliedCb.disabled = true;
      suggestions = suggestFor(doc);
      checked.clear();
      meta.textContent = `${doc.slug} \xB7 ${doc.url} \xB7 ${doc.nodes.length} nodes \xB7 ${doc.docWidth}\xD7${doc.docHeight}`;
      stage.classList.add("hasdoc");
      verifyBtn.hidden = false;
      dlOps.hidden = true;
      dlApplied.hidden = true;
      renderCanvas();
      renderSuggestions();
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e));
    }
  }
  fileInput.addEventListener("change", () => {
    const f = fileInput.files?.[0];
    if (f) void loadFile(f);
  });
  for (const ev of ["dragover", "dragenter"]) {
    stage.addEventListener(ev, (e) => {
      e.preventDefault();
      dropHint.classList.add("drag");
    });
  }
  for (const ev of ["dragleave", "drop"]) {
    stage.addEventListener(ev, (e) => {
      e.preventDefault();
      dropHint.classList.remove("drag");
    });
  }
  stage.addEventListener("drop", (e) => {
    const f = e.dataTransfer?.files?.[0];
    if (f) void loadFile(f);
  });
  var MAX_RENDERED_NODES = 8e3;
  function cssColor(c) {
    const h = (v) => Math.round(v * 255).toString(16).padStart(2, "0");
    return c.a >= 1 ? "#" + h(c.r) + h(c.g) + h(c.b) : `rgba(${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)},${c.a})`;
  }
  function renderCanvas() {
    if (!doc) return;
    canvas.textContent = "";
    const scale = Math.min(1, (stage.clientWidth - 24) / doc.docWidth);
    wrap.style.transform = `scale(${scale})`;
    wrap.style.width = doc.docWidth + "px";
    wrap.style.height = doc.docHeight + "px";
    canvas.style.position = "relative";
    const frag = document.createDocumentFragment();
    const nodes = doc.nodes.slice(0, MAX_RENDERED_NODES);
    for (const n of nodes) {
      const el = document.createElement("div");
      el.className = "node" + (n.kind === "text" ? " text" : "");
      el.dataset["id"] = n.id;
      Object.assign(el.style, {
        left: n.x + "px",
        top: n.y + "px",
        width: Math.max(n.w, 1) + "px",
        height: Math.max(n.h, 1) + "px",
        opacity: String(n.opacity ?? 1)
      });
      if (n.kind === "text") {
        el.style.color = n.textColor ? cssColor(n.textColor) : "#000";
        el.style.fontSize = (n.fontSize ?? 16) + "px";
        el.style.fontWeight = String(n.fontWeight ?? 400);
        el.style.lineHeight = n.lineHeight ? n.lineHeight + "px" : "normal";
        el.style.textAlign = (n.textAlign ?? "LEFT").toLowerCase() === "center" ? "center" : (n.textAlign ?? "").toLowerCase() === "right" ? "right" : "left";
        el.textContent = n.text ?? "";
      } else if (n.kind === "image") {
        el.style.background = n.imageDataUrl ? `center/cover no-repeat url("${n.imageDataUrl}")` : "#8a8f98";
      } else if (n.kind === "vector") {
        el.style.outline = "1px dashed #5a6472";
      } else {
        if (n.bgColor && n.bgColor.a > 0) el.style.background = cssColor(n.bgColor);
        if (n.border && n.border.width > 0) {
          el.style.borderStyle = "solid";
          el.style.borderWidth = n.border.width + "px";
          el.style.borderColor = cssColor(n.border.color);
        }
      }
      if (n.radii) {
        const [tl, tr, br, bl] = n.radii;
        el.style.borderRadius = `${tl}px ${tr}px ${br}px ${bl}px`;
      }
      el.addEventListener("click", () => {
        for (const hot of canvas.querySelectorAll(".hot")) hot.classList.remove("hot");
        el.classList.add("hot");
        toast(`${n.id} <${n.tag.toLowerCase()}> ${Math.round(n.w)}\xD7${Math.round(n.h)} @ ${Math.round(n.x)},${Math.round(n.y)}`);
      });
      frag.appendChild(el);
    }
    canvas.appendChild(frag);
    if (doc.nodes.length > MAX_RENDERED_NODES) {
      toast(`rendered first ${MAX_RENDERED_NODES} of ${doc.nodes.length} nodes`);
    }
  }
  window.addEventListener("resize", () => {
    if (doc) renderCanvas();
  });
  function severityChip(sev) {
    const chip = document.createElement("span");
    chip.className = "sev " + sev;
    chip.textContent = sev.toUpperCase();
    return chip;
  }
  function updateCount() {
    selCount.textContent = `${checked.size}/${suggestions.length} selected`;
    applyBtn.disabled = checked.size === 0;
    for (const li of list.children) {
      const cb = li.querySelector("input");
      if (cb && cb.dataset["sid"]) cb.checked = checked.has(cb.dataset["sid"]);
    }
  }
  function renderSuggestions() {
    list.textContent = "";
    const frag = document.createDocumentFragment();
    suggestions.forEach((s) => {
      const li = document.createElement("li");
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.disabled = s.fixes.length === 0;
      cb.dataset["sid"] = s.id;
      if (s.fixes.length === 0) cb.title = "report-only finding (no automated fix)";
      cb.addEventListener("change", () => {
        if (cb.checked) checked.add(s.id);
        else checked.delete(s.id);
        updateCount();
      });
      li.appendChild(cb);
      li.appendChild(severityChip(s.severity));
      const rule = document.createElement("span");
      rule.className = "rule";
      rule.textContent = s.rule;
      li.appendChild(rule);
      const msg = document.createElement("div");
      msg.className = "msg";
      msg.textContent = s.message + (s.fixes.length ? "" : "  \xB7 report only");
      msg.addEventListener("click", () => {
        const target = doc?.nodes.find((n) => n.id === s.targetIds[0]);
        if (!target) return;
        for (const hot of canvas.querySelectorAll(".hot")) hot.classList.remove("hot");
        const el = canvas.querySelector(`[data-id="${target.id}"]`);
        if (el) {
          el.classList.add("hot");
          el.scrollIntoView({ block: "nearest", behavior: "smooth" });
        }
      });
      li.appendChild(msg);
      if (checked.has(s.id)) cb.checked = true;
      frag.appendChild(li);
    });
    list.appendChild(frag);
    updateCount();
  }
  selAll.addEventListener("click", () => {
    for (const s of suggestions) if (s.fixes.length) checked.add(s.id);
    updateCount();
  });
  selNone.addEventListener("click", () => {
    checked.clear();
    updateCount();
  });
  applyBtn.addEventListener("click", () => {
    if (!doc) return;
    const chosen = suggestions.filter((s) => checked.has(s.id));
    const fixes = chosen.flatMap((s) => s.fixes);
    if (!fixes.length) {
      toast("selected findings carry no automated fixes");
      return;
    }
    const ops = fixesToFigmaOps(fixes);
    appliedDoc = applyFixesToDoc(doc, fixes);
    download(`${doc.slug}.ops.json`, { slug: doc.slug, ops });
    download(`${doc.slug}.applied.capture.json`, appliedDoc);
    dlOps.href = URL.createObjectURL(
      new Blob([JSON.stringify({ slug: doc.slug, ops }, null, 2)], { type: "application/json" })
    );
    dlApplied.href = URL.createObjectURL(
      new Blob([JSON.stringify(appliedDoc, null, 2)], { type: "application/json" })
    );
    dlOps.hidden = false;
    dlApplied.hidden = false;
    useAppliedCb.disabled = false;
    useAppliedCb.checked = true;
    toast(`${ops.length} ops generated \u2014 run plugin Apply mode, then Verify`);
  });
  var LS_TOK = "ua.token";
  var LS_KEY = "ua.filekey";
  tokInput.value = localStorage.getItem(LS_TOK) ?? "";
  fkeyInput.value = localStorage.getItem(LS_KEY) ?? "";
  verifyBtn.addEventListener("click", () => {
    verifyPanel.hidden = !verifyPanel.hidden;
  });
  runVerifyBtn.addEventListener("click", async () => {
    if (!doc) {
      toast("load a capture first");
      return;
    }
    const token = tokInput.value.trim();
    const fileKey = fkeyInput.value.trim().match(/([A-Za-z0-9]{6,})\s*$/)?.[1] ?? fkeyInput.value.trim();
    if (!token || !fileKey) {
      toast("token and file key required");
      return;
    }
    localStorage.setItem(LS_TOK, token);
    localStorage.setItem(LS_KEY, fileKey);
    const baseline = useAppliedCb.checked && appliedDoc ? appliedDoc : doc;
    runVerifyBtn.disabled = true;
    verifyOut.textContent = `verifying ${baseline.slug} vs ${useAppliedCb.checked && appliedDoc ? "applied" : "original"} baseline\u2026`;
    try {
      let report;
      if (uaDesktop) {
        const r = await uaDesktop.verify({ token, fileKey, capture: baseline });
        if (!r.ok || !r.report) throw new Error(r.error ?? "bridge verify failed");
        report = r.report;
      } else {
        report = await verifyCapture({ token, fileKey, capture: baseline });
      }
      const badge = document.createElement("span");
      badge.className = "badge " + (report.passed ? "pass" : "fail");
      badge.textContent = report.passed ? "PASS" : "FAIL";
      const lines = [
        `coverage ${(report.coverage * 100).toFixed(2)}% (${report.found}/${report.total})`,
        `mismatches: ${report.mismatches.length}`,
        ...report.mismatches.slice(0, 30).map(
          (m) => `${m.id.padEnd(8)} ${m.field.padEnd(11)} expected=${m.expected} actual=${m.actual}` + (m.delta !== void 0 ? ` \u0394=${m.delta}` : "")
        ),
        ...report.mismatches.length > 30 ? [`\u2026 +${report.mismatches.length - 30} more`] : []
      ];
      verifyOut.textContent = "";
      verifyOut.appendChild(badge);
      verifyOut.appendChild(document.createTextNode("\n" + lines.join("\n")));
    } catch (e) {
      verifyOut.textContent = "verify failed: " + (e instanceof Error ? e.message : String(e));
    } finally {
      runVerifyBtn.disabled = false;
    }
  });
  window["__ua"] = {
    loadJSON(text) {
      return loadFile(new File([text], "smoke.capture.json", { type: "application/json" }));
    }
  };
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    navigator.serviceWorker.register("./sw.js").catch(() => {
    });
  }
  var extGlobal = globalThis;
  var extRuntime = extGlobal.chrome?.runtime;
  if (extRuntime?.id && typeof extRuntime.sendMessage === "function") {
    captureTabBtn.hidden = false;
    captureTabBtn.addEventListener("click", () => {
      captureTabBtn.disabled = true;
      extRuntime.sendMessage({ type: "CAPTURE_TAB" }, (resp) => {
        captureTabBtn.disabled = false;
        const err = extRuntime.lastError?.message ?? resp?.error;
        if (err || !resp?.ok || !resp.doc) {
          toast("capture failed: " + (err ?? "unknown"));
          return;
        }
        void loadFile(
          new File([JSON.stringify(resp.doc)], (resp.doc.slug || "tab") + ".capture.json", {
            type: "application/json"
          })
        );
      });
    });
  }
  var convUrlInput = $("convUrl");
  var convBtn = $("convBtn");
  if (uaDesktop) {
    convUrlInput.hidden = false;
    convBtn.hidden = false;
    void uaDesktop.chromiumPath?.().then((r) => {
      if (!r.ok) toast("convert disabled \u2014 " + r.error);
    });
    const runConvert = async () => {
      const url = convUrlInput.value.trim();
      if (!/^https?:\/\//.test(url)) {
        toast("enter an http(s) URL");
        return;
      }
      convBtn.disabled = true;
      convBtn.textContent = "Capturing\u2026";
      const r = await uaDesktop.convert({ url });
      convBtn.disabled = false;
      convBtn.textContent = "Convert";
      if (!r.ok || !r.doc) {
        toast("convert failed: " + (r.error ?? "unknown"));
        return;
      }
      await loadFile(
        new File([JSON.stringify(r.doc)], (r.doc.slug || "page") + ".capture.json", {
          type: "application/json"
        })
      );
    };
    convBtn.addEventListener("click", () => void runConvert());
    convUrlInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") void runConvert();
    });
  }
})();
